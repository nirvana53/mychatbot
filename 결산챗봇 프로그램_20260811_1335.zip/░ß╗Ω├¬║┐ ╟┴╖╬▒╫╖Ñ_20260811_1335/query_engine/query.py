"""SQLite(finance.db)에서 연결결산 데이터를 조회/집계하는 함수 모음.

데이터는 (법인 20개 + 연결조정)의 3단계 계정트리(대분류-중분류-세부계정)로
저장되어 있다. entity를 지정하지 않으면 모든 법인 + 연결조정을 합산한
"연결" 기준 값을 돌려준다(법인별 데이터 + 연결조정 = 연결결산이라는
전제와 그대로 맞는 동작이다). 특정 법인명을 넘기면 그 법인만 걸러서
조회한다(드릴다운).

챗봇 오케스트레이터(chatbot.py)가 nlu.parse_question()의 결과에 따라
이 모듈의 함수를 호출해서 실제 숫자를 가져온다. 숫자 계산은 항상 이
모듈(=DB 조회)에서만 하고, LLM에게는 결과를 문장으로 다듬는 역할만
맡기는 것이 원칙이다.
"""

import sqlite3
from functools import lru_cache

import config

# 여러 대분류를 더하고 빼서 만드는 계산 지표. 원본 데이터에는 이 항목들이
# 행으로 저장되어 있지 않고, 조회 시점에 대분류 합계로 계산한다.
COMPUTED_METRICS = {
    "매출총이익": [("매출", 1), ("매출원가", -1)],
    "영업이익": [("매출", 1), ("매출원가", -1), ("판매비와관리비", -1)],
    "영업외손익": [("영업외수익", 1), ("영업외비용", -1)],
    "세전이익": [
        ("매출", 1), ("매출원가", -1), ("판매비와관리비", -1),
        ("영업외수익", 1), ("영업외비용", -1),
    ],
    "당기순이익": [
        ("매출", 1), ("매출원가", -1), ("판매비와관리비", -1),
        ("영업외수익", 1), ("영업외비용", -1), ("법인세", -1),
    ],
}

# 전체 재무제표 뷰("손익계산서/재무상태표 보여줘")를 사람이 읽는 순서 그대로
# 구성하기 위한 줄 순서 정의.
#   "section": 대분류 하나의 중분류/세부계정 상세를 모두 보여준 뒤, 그
#              대분류 총액 한 줄을 덧붙인다(자산 세부 -> 자산총계, 매출
#              세부 -> 매출, ...). 모든 대분류 줄은 세부계정까지 함께 보여야
#              한다는 요구사항 때문에 "total"(상세 없이 합계만) 대신 이걸 쓴다.
#   "section_metric": 대분류 여러 개(예: 영업외수익+영업외비용)의 상세를
#              한꺼번에 보여준 뒤, 그 순계(net) 계산 지표를 총액 줄로 붙인다
#              (영업외손익처럼 "수익-비용"을 하나의 줄로 합쳐 보여줄 때 사용).
#   "metric": 상세가 없는 순수 계산 지표 한 줄(매출총이익/영업이익/세전이익/
#              당기순이익처럼, 이미 위에서 보여준 대분류들의 조합이라 상세를
#              또 보여주면 중복이 되는 경우).
STATEMENT_LAYOUT = {
    "손익계산서": [
        ("section", "매출", "매출"),
        ("section", "매출원가", "매출원가"),
        ("metric", "매출총이익", "매출총이익"),
        ("section", "판매비와관리비", "판관비"),
        ("metric", "영업이익", "영업이익"),
        ("section_metric", ["영업외수익", "영업외비용"], "영업외손익", "영업외손익"),
        ("metric", "세전이익", "세전이익"),
        ("section", "법인세", "법인세"),
        ("metric", "당기순이익", "당기순이익"),
    ],
    "재무상태표": [
        ("section", "자산", "자산총계"),
        ("section", "부채", "부채총계"),
        ("section", "자본", "자본총계"),
    ],
}

# 두 계산 지표(또는 대분류)의 비율로 만드는 지표. (분자, 분모) 각각
# COMPUTED_METRICS에 있으면 metric으로, 아니면 level1 대분류 합계로 계산한다.
RATIO_METRICS = {
    "영업이익률": ("영업이익", "매출"),
    "매출원가율": ("매출원가", "매출"),
    "부채비율": ("부채", "자본"),
    "ROE": ("당기순이익", "자본"),
    "ROA": ("당기순이익", "자산"),
}

UNIT = "백만원"
RATIO_UNIT = "%"


def _connect():
    return sqlite3.connect(config.DB_PATH)


@lru_cache(maxsize=None)
def list_entities() -> list:
    try:
        with _connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT entity FROM financial_statements ORDER BY entity"
            ).fetchall()
        return [r[0] for r in rows]
    except sqlite3.OperationalError:
        return []


@lru_cache(maxsize=None)
def list_accounts() -> dict:
    """레벨별 계정명과 계산 지표 이름을 함께 반환한다."""
    try:
        with _connect() as conn:
            level1 = [r[0] for r in conn.execute(
                "SELECT DISTINCT level1 FROM financial_statements ORDER BY level1"
            ).fetchall()]
            level2 = [r[0] for r in conn.execute(
                "SELECT DISTINCT level2 FROM financial_statements WHERE level2 IS NOT NULL ORDER BY level2"
            ).fetchall()]
            level3 = [r[0] for r in conn.execute(
                "SELECT DISTINCT level3 FROM financial_statements WHERE level3 IS NOT NULL ORDER BY level3"
            ).fetchall()]
        return {
            "level1": level1,
            "level2": level2,
            "level3": level3,
            "metrics": list(COMPUTED_METRICS.keys()),
            "ratios": list(RATIO_METRICS.keys()),
        }
    except sqlite3.OperationalError:
        return {"level1": [], "level2": [], "level3": [], "metrics": [], "ratios": []}


@lru_cache(maxsize=None)
def get_periods() -> list:
    try:
        with _connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT year, quarter FROM financial_statements ORDER BY year, quarter"
            ).fetchall()
        return [(r[0], r[1]) for r in rows]
    except sqlite3.OperationalError:
        return []


def _level_column(level: str) -> str:
    return {"level1": "level1", "level2": "level2", "level3": "level3"}[level]


def _sum_leaf(conn, year, quarter, level, value, entity=None):
    column = _level_column(level)
    query = f"SELECT COALESCE(SUM(amount),0) FROM financial_statements WHERE year=? AND quarter=? AND {column}=?"
    params = [year, quarter, value]
    if entity:
        query += " AND entity=?"
        params.append(entity)
    return conn.execute(query, params).fetchone()[0]


def _has_data(conn, year, quarter, level, value, entity=None):
    column = _level_column(level)
    query = f"SELECT 1 FROM financial_statements WHERE year=? AND quarter=? AND {column}=?"
    params = [year, quarter, value]
    if entity:
        query += " AND entity=?"
        params.append(entity)
    query += " LIMIT 1"
    return conn.execute(query, params).fetchone() is not None


@lru_cache(maxsize=None)
def get_amount(year: int, quarter: int, target: str, level: str, entity: str | None = None) -> dict:
    """entity가 None이면 법인 20개 + 연결조정을 모두 합산한 연결 기준 값."""
    if level == "ratio":
        spec = RATIO_METRICS.get(target)
        if spec is None:
            return {"found": False}
        num_name, den_name = spec
        num = get_amount(year, quarter, num_name, "metric" if num_name in COMPUTED_METRICS else "level1", entity)
        den = get_amount(year, quarter, den_name, "metric" if den_name in COMPUTED_METRICS else "level1", entity)
        if not (num.get("found") and den.get("found")) or not den.get("amount"):
            return {"found": False}
        return {"found": True, "amount": num["amount"] / den["amount"] * 100, "unit": RATIO_UNIT}

    with _connect() as conn:
        if level == "metric":
            formula = COMPUTED_METRICS.get(target)
            if formula is None:
                return {"found": False}
            total = 0.0
            any_found = False
            for level1_value, sign in formula:
                if _has_data(conn, year, quarter, "level1", level1_value, entity):
                    any_found = True
                total += sign * _sum_leaf(conn, year, quarter, "level1", level1_value, entity)
            if not any_found:
                return {"found": False}
            return {"found": True, "amount": total, "unit": UNIT}

        if not _has_data(conn, year, quarter, level, target, entity):
            return {"found": False}
        amount = _sum_leaf(conn, year, quarter, level, target, entity)
    return {"found": True, "amount": amount, "unit": UNIT}


@lru_cache(maxsize=None)
def get_trend(target: str, level: str, entity: str | None = None, year: int | None = None,
              period_start: tuple | None = None, period_end: tuple | None = None) -> list:
    periods = get_periods()
    if period_start is not None and period_end is not None:
        periods = [p for p in periods if period_start <= p <= period_end]
    elif year is not None:
        periods = [p for p in periods if p[0] == year]
    rows = []
    for y, q in periods:
        result = get_amount(y, q, target, level, entity)
        if result.get("found"):
            rows.append({"year": y, "quarter": q, "amount": result["amount"], "unit": result.get("unit", UNIT)})
    return rows


@lru_cache(maxsize=None)
def compare_periods(target: str, level: str, period_a: tuple, period_b: tuple, entity: str | None = None) -> dict:
    a = get_amount(period_a[0], period_a[1], target, level, entity)
    b = get_amount(period_b[0], period_b[1], target, level, entity)
    result = {
        "point_a": {"year": period_a[0], "quarter": period_a[1], "amount": a.get("amount")},
        "point_b": {"year": period_b[0], "quarter": period_b[1], "amount": b.get("amount")},
        "unit": a.get("unit") or b.get("unit") or UNIT,
    }
    if a.get("found") and b.get("found"):
        diff = b["amount"] - a["amount"]
        result["diff"] = diff
        result["pct_change"] = (diff / a["amount"] * 100) if a["amount"] else None
    return result


@lru_cache(maxsize=None)
def get_period_comparisons(year: int, quarter: int, target: str, level: str, entity: str | None = None) -> dict:
    """단일 시점 조회에 자동으로 곁들이는 전분기(QoQ)/전년동기(YoY) 비교."""
    periods = get_periods()
    result = {}
    if (year, quarter) in periods:
        idx = periods.index((year, quarter))
        if idx > 0:
            prev = periods[idx - 1]
            result["qoq"] = compare_periods(target, level, prev, (year, quarter), entity)
    yoy_period = (year - 1, quarter)
    if yoy_period in periods:
        result["yoy"] = compare_periods(target, level, yoy_period, (year, quarter), entity)
    return result


@lru_cache(maxsize=None)
def get_ytd_amount(year: int, target: str, level: str, entity: str | None = None) -> dict:
    """연간 누적(YTD) 값. 해당 연도에 적재된 분기를 모두 더한다(미래 분기가
    아직 없으므로 "지금까지 누적"과 같은 의미가 된다). level1/metric은
    분기별 금액을 그대로 합산하면 되지만, ratio는 %를 그냥 더하면 안 되므로
    분자·분모를 각각 누적한 뒤 다시 나눈다(누적 매출원가율 = 누적 매출원가
    / 누적 매출, 개별 분기 비율의 평균이 아니라 이 방식이 맞다)."""
    periods = [p for p in get_periods() if p[0] == year]
    if not periods:
        return {"found": False}

    if level == "ratio":
        spec = RATIO_METRICS.get(target)
        if spec is None:
            return {"found": False}
        num_name, den_name = spec
        num = get_ytd_amount(year, num_name, "metric" if num_name in COMPUTED_METRICS else "level1", entity)
        den = get_ytd_amount(year, den_name, "metric" if den_name in COMPUTED_METRICS else "level1", entity)
        if not (num.get("found") and den.get("found")) or not den.get("amount"):
            return {"found": False}
        return {"found": True, "amount": num["amount"] / den["amount"] * 100, "unit": RATIO_UNIT, "quarters": len(periods)}

    total = 0.0
    any_found = False
    for y, q in periods:
        result = get_amount(y, q, target, level, entity)
        if result.get("found"):
            any_found = True
            total += result["amount"]
    if not any_found:
        return {"found": False}
    return {"found": True, "amount": total, "unit": UNIT, "quarters": len(periods)}


@lru_cache(maxsize=None)
def compare_subaccount_contributions(target: str, level: str, period_a: tuple, period_b: tuple,
                                      entity: str | None = None, top_n: int = 5) -> list:
    """두 시점 사이의 변동을 세부계정 단위로 쪼개서, 변동에 가장 크게 기여한 항목부터 보여준다."""
    a_rows = breakdown_by_subaccount(period_a[0], period_a[1], level, target, entity)
    b_rows = breakdown_by_subaccount(period_b[0], period_b[1], level, target, entity)
    a_map = {r["label"]: r["amount"] for r in a_rows}
    b_map = {r["label"]: r["amount"] for r in b_rows}
    diffs = [
        {"label": label, "diff": b_map.get(label, 0) - a_map.get(label, 0), "unit": UNIT}
        for label in (set(a_map) | set(b_map))
    ]
    diffs.sort(key=lambda d: -abs(d["diff"]))
    return diffs[:top_n]


@lru_cache(maxsize=None)
def breakdown_by_entity(year: int, quarter: int, target: str, level: str) -> list:
    """법인별(+연결조정) 기여도 breakdown. 절대값이 큰 순서로 정렬."""
    entities = list_entities()
    rows = []
    for e in entities:
        result = get_amount(year, quarter, target, level, entity=e)
        if result.get("found"):
            rows.append({"entity": e, "amount": result["amount"], "unit": result.get("unit", UNIT)})
    rows.sort(key=lambda r: -abs(r["amount"]))
    return rows


@lru_cache(maxsize=None)
def _level3_amounts(year: int, quarter: int, entity: str | None = None) -> dict:
    query = """SELECT level3, COALESCE(SUM(amount),0) FROM financial_statements
               WHERE year=? AND quarter=? AND level3 IS NOT NULL"""
    params = [year, quarter]
    if entity:
        query += " AND entity=?"
        params.append(entity)
    query += " GROUP BY level3"
    with _connect() as conn:
        rows = conn.execute(query, params).fetchall()
    return {r[0]: r[1] for r in rows}


@lru_cache(maxsize=None)
def get_new_accounts(year: int, quarter: int, entity: str | None = None) -> list:
    """직전 분기에는 금액이 없었는데(0 또는 미기록) 이번 분기에 처음 생긴 세부계정."""
    periods = get_periods()
    if (year, quarter) not in periods or periods.index((year, quarter)) == 0:
        return []
    prev_year, prev_quarter = periods[periods.index((year, quarter)) - 1]

    current = _level3_amounts(year, quarter, entity)
    previous = _level3_amounts(prev_year, prev_quarter, entity)
    new_items = [
        {"label": label, "amount": amount, "unit": UNIT}
        for label, amount in current.items()
        if amount != 0 and previous.get(label, 0) == 0
    ]
    new_items.sort(key=lambda r: -abs(r["amount"]))
    return new_items


@lru_cache(maxsize=None)
def detect_account_anomalies(year: int, quarter: int, entity: str | None = None, z_threshold: float = 1.5) -> list:
    """법인 단위가 아니라 세부계정 단위로, 전분기 대비 변동이 유독 큰 계정을 찾는다."""
    periods = get_periods()
    if (year, quarter) not in periods or periods.index((year, quarter)) == 0:
        return []
    prev_year, prev_quarter = periods[periods.index((year, quarter)) - 1]

    current = _level3_amounts(year, quarter, entity)
    previous = _level3_amounts(prev_year, prev_quarter, entity)
    diffs = [
        {"label": label, "amount": amount, "prev_amount": previous.get(label, 0),
         "diff": amount - previous.get(label, 0), "unit": UNIT}
        for label, amount in current.items()
    ]
    if len(diffs) < 3:
        return []
    diff_values = [d["diff"] for d in diffs]
    mean = sum(diff_values) / len(diff_values)
    std = (sum((v - mean) ** 2 for v in diff_values) / len(diff_values)) ** 0.5
    if std == 0:
        return []
    outliers = [{**d, "z_score": (d["diff"] - mean) / std} for d in diffs if abs((d["diff"] - mean) / std) >= z_threshold]
    outliers.sort(key=lambda r: -abs(r["z_score"]))
    return outliers


def get_amounts_for_entities(year: int, quarter: int, target: str, level: str, entities: list) -> list:
    """사용자가 직접 지정한 법인들만 나란히 비교할 때 쓴다."""
    rows = []
    for e in entities:
        result = get_amount(year, quarter, target, level, entity=e)
        if result.get("found"):
            rows.append({"entity": e, "amount": result["amount"], "unit": result.get("unit", UNIT)})
    return rows


@lru_cache(maxsize=None)
def detect_entity_outliers(year: int, quarter: int, target: str, level: str, z_threshold: float = 1.5) -> list:
    """법인별 금액 분포에서 평균과 표준편차 대비 크게 벗어난 법인을 찾는다.

    연결조정은 법인들의 실적을 맞추기 위한 잔차(plug)라 다른 법인과 성격이
    달라서, 평균/표준편차 계산과 이상치 판정 모두에서 제외한다.
    """
    rows = [r for r in breakdown_by_entity(year, quarter, target, level) if r["entity"] != "연결조정"]
    if len(rows) < 3:
        return []
    amounts = [r["amount"] for r in rows]
    mean = sum(amounts) / len(amounts)
    std = (sum((a - mean) ** 2 for a in amounts) / len(amounts)) ** 0.5
    if std == 0:
        return []
    outliers = []
    for r in rows:
        z = (r["amount"] - mean) / std
        if abs(z) >= z_threshold:
            outliers.append({**r, "z_score": z, "mean": mean})
    outliers.sort(key=lambda r: -abs(r["z_score"]))
    return outliers


@lru_cache(maxsize=None)
def get_matrix(target: str, level: str) -> dict:
    """분기를 열, 법인(+연결조정)을 행으로 하는 매트릭스. "표로 보여줘"류
    질문에서 쓴다. 특정 법인 하나로 좁히는 게 아니라 전체를 한 번에 보는
    것이 매트릭스의 목적이라 entity 필터는 받지 않는다."""
    periods = get_periods()
    entities = list_entities()
    data = {}
    for e in entities:
        row = {}
        for year, quarter in periods:
            result = get_amount(year, quarter, target, level, entity=e)
            row[(year, quarter)] = result.get("amount") if result.get("found") else None
        data[e] = row
    return {"periods": periods, "entities": entities, "data": data}


def get_entity_target_matrix(year: int, quarter: int, targets: list) -> dict:
    """법인을 행, 계정을 열로 하는 교차표. "매출이랑 영업이익 법인별로
    보여줘"처럼 계정을 2개 이상 지정하면서 동시에 법인별로 나누고 싶을 때
    쓴다. `targets`는 `[(target, level), ...]`라 리스트를 인자로 받으므로
    (해시 불가능) get_amounts_for_entities와 같은 이유로 캐시하지 않는다 —
    내부에서 부르는 get_amount는 이미 캐시되어 있어 이득은 대부분 남는다.
    계정마다 단위가 다를 수 있어(예: 매출=백만원, 영업이익률=%) 단위도
    계정별로 따로 돌려준다."""
    entities = list_entities()
    data = {}
    units = {}
    for target, level in targets:
        column = {}
        for e in entities:
            result = get_amount(year, quarter, target, level, entity=e)
            column[e] = result.get("amount") if result.get("found") else None
            if result.get("found"):
                units[target] = result.get("unit", UNIT)
        data[target] = column
    return {"entities": entities, "targets": [t[0] for t in targets], "data": data, "units": units}


def _statement_detail_rows(conn, year, quarter, statement_type, level1_list, entity):
    placeholders = ",".join("?" for _ in level1_list)
    leaf_sql = f"""SELECT level1, level2, level3, COALESCE(SUM(amount),0) FROM financial_statements
                   WHERE year=? AND quarter=? AND statement_type=? AND level1 IN ({placeholders})"""
    params = [year, quarter, statement_type, *level1_list]
    if entity:
        leaf_sql += " AND entity=?"
        params.append(entity)
    leaf_sql += " GROUP BY level1, level2, level3 ORDER BY level1, level2, level3"
    return conn.execute(leaf_sql, params).fetchall()


@lru_cache(maxsize=None)
def get_statement(year: int, quarter: int, statement_type: str, entity: str | None = None) -> dict:
    """계정 하나씩이 아니라 전체 재무제표를, 세부계정까지 포함해서 사람이
    읽는 줄 순서 그대로 돌려준다("손익계산서 보여줘"). STATEMENT_LAYOUT에
    정의된 순서를 그대로 따라가며 줄을 쌓는다("section"/"section_metric"은
    중분류·세부계정 상세 뒤에 합계 한 줄을, "metric"은 상세 없이 계산 지표
    합계 한 줄만 붙인다). 반환하는 "lines"는 이미 최종 표시 순서이므로,
    호출부(chatbot.py/mock_client.py)는 재정렬할 필요가 없다.
    """
    layout = STATEMENT_LAYOUT.get(statement_type)
    if layout is None:
        return {"found": False}

    lines = []
    any_found = False
    with _connect() as conn:
        for kind, *spec in layout:
            if kind == "metric":
                metric_name, label = spec
                result = get_amount(year, quarter, metric_name, "metric", entity)
                if result.get("found"):
                    any_found = True
                lines.append({"kind": "metric", "label": label, "amount": result.get("amount", 0.0)})

            elif kind == "section":
                level1, subtotal_label = spec
                for l1, l2, l3, amount in _statement_detail_rows(conn, year, quarter, statement_type, [level1], entity):
                    any_found = True
                    lines.append({"kind": "detail", "level1": l1, "level2": l2, "level3": l3, "amount": amount})
                subtotal = get_amount(year, quarter, level1, "level1", entity)
                lines.append({"kind": "total", "label": subtotal_label, "amount": subtotal.get("amount", 0.0)})

            elif kind == "section_metric":
                level1_list, subtotal_label, metric_name = spec
                for l1, l2, l3, amount in _statement_detail_rows(conn, year, quarter, statement_type, level1_list, entity):
                    any_found = True
                    lines.append({"kind": "detail", "level1": l1, "level2": l2, "level3": l3, "amount": amount})
                subtotal = get_amount(year, quarter, metric_name, "metric", entity)
                lines.append({"kind": "metric", "label": subtotal_label, "amount": subtotal.get("amount", 0.0)})

    if not any_found:
        return {"found": False}
    return {"found": True, "lines": lines, "unit": UNIT}


@lru_cache(maxsize=None)
def breakdown_by_subaccount(year: int, quarter: int, level: str, value: str, entity: str | None = None) -> list:
    """계정트리를 한 단계 더 파고든다: 대분류 -> 중분류, 중분류 -> 세부계정."""
    if level == "level1":
        group_col, filter_col = "level2", "level1"
    elif level == "level2":
        group_col, filter_col = "level3", "level2"
    else:
        return []

    query = f"""SELECT {group_col}, COALESCE(SUM(amount),0) FROM financial_statements
                WHERE year=? AND quarter=? AND {filter_col}=? AND {group_col} IS NOT NULL"""
    params = [year, quarter, value]
    if entity:
        query += " AND entity=?"
        params.append(entity)
    query += f" GROUP BY {group_col} ORDER BY {group_col}"

    with _connect() as conn:
        rows = conn.execute(query, params).fetchall()
    return [{"label": r[0], "amount": r[1], "unit": UNIT} for r in rows]


@lru_cache(maxsize=None)
def get_budget_amount(year: int, quarter: int, target: str, level: str) -> dict:
    """budget 테이블에서 값을 가져온다. budget은 대분류(level1) 단위로만
    적재되므로, level1은 직접 합계, metric/ratio는 실적과 똑같은 공식을
    예산 대분류 값에 적용해서 재계산한다. level2/level3는 지원하지 않는다
    (예산에 그 정도 세부 데이터가 없다는 전제)."""
    if level == "ratio":
        spec = RATIO_METRICS.get(target)
        if spec is None:
            return {"found": False}
        num_name, den_name = spec
        num = get_budget_amount(year, quarter, num_name, "metric" if num_name in COMPUTED_METRICS else "level1")
        den = get_budget_amount(year, quarter, den_name, "metric" if den_name in COMPUTED_METRICS else "level1")
        if not (num.get("found") and den.get("found")) or not den.get("amount"):
            return {"found": False}
        return {"found": True, "amount": num["amount"] / den["amount"] * 100, "unit": RATIO_UNIT}

    with _connect() as conn:
        if level == "metric":
            formula = COMPUTED_METRICS.get(target)
            if formula is None:
                return {"found": False}
            total = 0.0
            any_found = False
            for level1_value, sign in formula:
                exists = conn.execute(
                    "SELECT 1 FROM budget WHERE year=? AND quarter=? AND level1=? LIMIT 1", (year, quarter, level1_value)
                ).fetchone() is not None
                if exists:
                    any_found = True
                amount = conn.execute(
                    "SELECT COALESCE(SUM(amount),0) FROM budget WHERE year=? AND quarter=? AND level1=?", (year, quarter, level1_value)
                ).fetchone()[0]
                total += sign * amount
            if not any_found:
                return {"found": False}
            return {"found": True, "amount": total, "unit": UNIT}

        if level != "level1":
            return {"found": False}
        exists = conn.execute(
            "SELECT 1 FROM budget WHERE year=? AND quarter=? AND level1=? LIMIT 1", (year, quarter, target)
        ).fetchone() is not None
        if not exists:
            return {"found": False}
        amount = conn.execute(
            "SELECT COALESCE(SUM(amount),0) FROM budget WHERE year=? AND quarter=? AND level1=?", (year, quarter, target)
        ).fetchone()[0]
        return {"found": True, "amount": amount, "unit": UNIT}


@lru_cache(maxsize=None)
def get_budget_vs_actual(year: int, quarter: int, target: str, level: str) -> dict:
    actual = get_amount(year, quarter, target, level)
    budget = get_budget_amount(year, quarter, target, level)
    result = {
        "actual_found": actual.get("found", False),
        "budget_found": budget.get("found", False),
        "actual": actual.get("amount"),
        "budget": budget.get("amount"),
        "unit": actual.get("unit") or budget.get("unit") or UNIT,
    }
    if result["actual_found"] and result["budget_found"] and budget.get("amount"):
        result["diff"] = actual["amount"] - budget["amount"]
        result["achievement_rate"] = actual["amount"] / budget["amount"] * 100
    return result


def clear_cache() -> None:
    """DB가 다시 적재된 뒤(ingest) 호출해서 이전 데이터로 계산된 캐시를 비운다.

    이 모듈의 조회 함수 대부분은 순수 SQLite 읽기이고 데이터셋이 작아서
    lru_cache로 무제한 메모이즈한다. get_amounts_for_entities만 법인
    리스트를 인자로 받아 해시 불가능이라 캐시하지 않는다(내부에서 호출하는
    get_amount는 이미 캐시되어 있어 이득은 대부분 그대로 남는다).
    """
    for fn in (
        list_entities, list_accounts, get_periods, get_amount, get_trend,
        compare_periods, get_period_comparisons, compare_subaccount_contributions,
        breakdown_by_entity, _level3_amounts, get_new_accounts,
        detect_account_anomalies, detect_entity_outliers, breakdown_by_subaccount, get_matrix,
        get_budget_amount, get_budget_vs_actual, get_statement, get_ytd_amount,
    ):
        fn.cache_clear()
