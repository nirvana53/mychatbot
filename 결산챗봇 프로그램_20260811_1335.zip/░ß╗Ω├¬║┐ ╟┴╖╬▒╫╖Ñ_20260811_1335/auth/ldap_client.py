"""사내 LDAP/AD 인증 연동 자리표시자.

사번 기반 정식 인증(로그인한 사람이 실제로 그 사번 본인인지 서버가 검증)을
붙이려면 사내 LDAP/AD 서버 접속 정보가 필요한데, 아직 그 정보가 없어서
실제 연동은 보류 상태다. 이 클래스는 llm/internal_agent_client.py와 같은
패턴의 자리표시자로, config.LDAP_AUTH_CONFIG가 비어 있으면 생성 시점에
바로 에러를 내서 "연결 안 된 백엔드가 조용히 항상 인증 실패/성공하는"
상황을 막는다.

연동 정보가 준비되면 아래 TODO 메서드 3개만 구현하면 되고, 호출부
(check_credentials -> _build_bind_request -> _bind -> _parse_response)는
바꿀 필요가 없다.
"""

import config

from .base import AuthBackend


class LDAPAuthBackend(AuthBackend):
    def __init__(self):
        if not config.LDAP_AUTH_CONFIG.get("server"):
            raise RuntimeError(
                "config.LDAP_AUTH_CONFIG가 비어 있습니다. 사내 LDAP/AD 서버 정보를 채운 뒤 "
                "config.ACTIVE_AUTH_BACKEND를 'ldap'으로 바꿔주세요."
            )

    def check_credentials(self, identifier: str, password: str) -> bool:
        payload = self._build_bind_request(identifier, password)
        response = self._bind(payload)
        return self._parse_response(response)

    def _build_bind_request(self, identifier: str, password: str):
        # TODO: config.LDAP_AUTH_CONFIG["bind_dn_template"]으로 사번(identifier)을
        # bind DN으로 조립한다. 예: template.format(uid=identifier)
        raise NotImplementedError("LDAP bind 요청 조립이 아직 구현되지 않았습니다.")

    def _bind(self, payload):
        # TODO: ldap3 등의 라이브러리로 config.LDAP_AUTH_CONFIG["server"]에
        # 실제 bind 요청을 보낸다.
        raise NotImplementedError("LDAP bind 호출이 아직 구현되지 않았습니다.")

    def _parse_response(self, response) -> bool:
        # TODO: bind 성공/실패를 bool로 판정한다.
        raise NotImplementedError("LDAP 응답 해석이 아직 구현되지 않았습니다.")
