"""회사 내부 AI agent LLM 연동용 자리표시자(placeholder) 구현.

지금은 내부 AI agent API에 접근할 수 없어서 실제 호출 코드를 완성하지
못했다. API 정보(엔드포인트, 인증 방식, 요청/응답 형식)를 받으면 아래
TODO 표시된 부분만 채우면 되도록 뼈대만 미리 만들어 두었다.

연동 순서:
1. config.py의 INTERNAL_AGENT_CONFIG에 endpoint/api_key/model 값을 채운다.
2. 아래 _build_payload / _call_api / _parse_response 세 함수를 실제 API
   스펙에 맞게 수정한다 (요청 바디 형식, 인증 헤더, 응답 JSON 구조 등).
3. config.ACTIVE_LLM_BACKEND를 "internal_agent"로 바꾼다.
그 외 코드(chatbot.py, app.py 등)는 수정할 필요가 없다.
"""

import json
import urllib.request

import config
from .base import LLMClient


class InternalAgentLLMClient(LLMClient):
    def __init__(self):
        self.cfg = config.INTERNAL_AGENT_CONFIG
        if not self.cfg.get("endpoint"):
            raise RuntimeError(
                "INTERNAL_AGENT_CONFIG['endpoint']가 설정되지 않았습니다. "
                "내부 AI agent API 연동 전에는 config.ACTIVE_LLM_BACKEND를 "
                "'mock'으로 두세요."
            )

    def generate_answer(self, question: str, context: dict) -> str:
        payload = self._build_payload(question, context)
        raw_response = self._call_api(payload)
        return self._parse_response(raw_response)

    def _build_payload(self, question: str, context: dict) -> dict:
        # TODO: 내부 AI agent가 요구하는 실제 요청 형식으로 교체.
        # 결산 데이터(context)는 이미 SQLite에서 조회된 결과이므로,
        # LLM에게는 "이 데이터를 바탕으로 자연스럽게 답변만 작성해줘" 라는
        # 역할만 맡기는 것을 권장한다(수치 계산을 LLM이 새로 하지 않도록).
        return {
            "model": self.cfg.get("model", ""),
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "다음은 회사 결산 데이터 조회 결과다. 이 데이터에 있는 "
                        "숫자만 사용해서 한국어로 간결하게 답변하라. 데이터에 "
                        "없는 내용은 추측하지 마라."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"질문: {question}\n조회 결과: {json.dumps(context, ensure_ascii=False)}"
                    ),
                },
            ],
        }

    def _call_api(self, payload: dict) -> dict:
        # TODO: 사내 인증 방식(API Key, 사내 SSO 토큰 등)에 맞게 헤더 수정.
        req = urllib.request.Request(
            self.cfg["endpoint"],
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.cfg.get('api_key', '')}",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=self.cfg.get("timeout", 30)) as resp:
            return json.loads(resp.read().decode("utf-8"))

    def _parse_response(self, raw_response: dict) -> str:
        # TODO: 실제 응답 JSON 구조에 맞게 경로 수정.
        try:
            return raw_response["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            return "내부 AI agent 응답 형식을 해석하지 못했습니다. 응답 파싱 로직을 확인해 주세요."
