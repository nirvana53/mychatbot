from .base import LLMClient
from .mock_client import MockLLMClient
from .internal_agent_client import InternalAgentLLMClient

_BACKENDS = {
    "mock": MockLLMClient,
    "internal_agent": InternalAgentLLMClient,
}


def get_llm_client(backend_name: str) -> LLMClient:
    """설정된 백엔드 이름으로 LLM 클라이언트를 생성한다.

    config.ACTIVE_LLM_BACKEND 값만 바꾸면 이 함수가 반환하는 구현체가
    바뀐다. 나머지 코드(챗봇 로직)는 LLMClient 인터페이스만 알고 있으므로
    수정할 필요가 없다.
    """
    if backend_name not in _BACKENDS:
        raise ValueError(f"알 수 없는 LLM 백엔드: {backend_name}")
    return _BACKENDS[backend_name]()
