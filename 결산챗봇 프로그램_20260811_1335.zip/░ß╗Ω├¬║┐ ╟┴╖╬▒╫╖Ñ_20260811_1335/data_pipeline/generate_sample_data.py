"""가상 연결결산 데이터 생성기.

실제 결산 자료가 준비되기 전까지 프로그램 개발/테스트에 쓰는 가상
데이터를 만든다. 회사의 실제 연결결산 구성을 반영해서:

- 계정은 대분류-중분류-세부계정의 3단계 트리로 구성한다.
- 데이터는 법인 20개(법인01~법인20)의 개별 데이터와, 내부거래 제거 등을
  반영하는 연결조정 1건으로 구성한다. 즉 (법인 20개 합산 + 연결조정) =
  연결결산 수치가 되도록 만든다. 챗봇은 기본적으로 이 21개 항목을 모두
  더한 값(연결 기준)으로 답하고, 특정 법인을 지정하면 그 법인만 조회한다.

실제 파일이 준비되면 이 가상 파일들은 지우고 실제 파일로 교체한다.
(컬럼명이 '법인/대분류/중분류/세부계정/금액'과 비슷하면 ingest.py가
그대로 인식하고, 다르면 ingest.py의 컬럼 매칭 키워드만 조정하면 된다.)

실행:
    python -m data_pipeline.generate_sample_data
"""

import random

import pandas as pd

import config

random.seed(42)

PERIODS = [
    (2024, 1), (2024, 2), (2024, 3), (2024, 4),
    (2025, 1), (2025, 2),
]

ENTITIES = [f"법인{str(i).zfill(2)}" for i in range(1, 21)]
ADJUSTMENT_ENTITY = "연결조정"

# (보고서구분, 대분류, 중분류, 세부계정, 연결 기준 시작금액, 분기당 증가율, 변동성)
LEAF_ACCOUNTS = [
    ("손익계산서", "매출", "제품매출", "국내제품매출", 5000, 0.02, 0.05),
    ("손익계산서", "매출", "제품매출", "수출제품매출", 3500, 0.025, 0.06),
    ("손익계산서", "매출", "상품매출", "국내상품매출", 700, 0.01, 0.07),
    ("손익계산서", "매출", "상품매출", "수출상품매출", 500, 0.01, 0.08),
    ("손익계산서", "매출", "용역매출", "용역매출", 900, 0.03, 0.06),

    ("손익계산서", "매출원가", "제품매출원가", "원재료비", 2800, 0.015, 0.05),
    ("손익계산서", "매출원가", "제품매출원가", "노무비", 1100, 0.01, 0.03),
    ("손익계산서", "매출원가", "상품매출원가", "매입원가", 900, 0.012, 0.06),

    ("손익계산서", "판매비와관리비", "인건비", "급여", 900, 0.015, 0.02),
    ("손익계산서", "판매비와관리비", "인건비", "복리후생비", 300, 0.01, 0.02),
    ("손익계산서", "판매비와관리비", "마케팅비", "광고선전비", 350, 0.0, 0.15),
    ("손익계산서", "판매비와관리비", "마케팅비", "판매촉진비", 150, 0.0, 0.15),
    ("손익계산서", "판매비와관리비", "일반관리비", "임차료", 220, 0.0, 0.01),
    ("손익계산서", "판매비와관리비", "일반관리비", "감가상각비", 260, 0.0, 0.02),
    ("손익계산서", "판매비와관리비", "일반관리비", "기타관리비", 200, 0.005, 0.08),

    ("손익계산서", "영업외수익", "금융수익", "이자수익", 55, 0.0, 0.1),
    ("손익계산서", "영업외수익", "기타수익", "기타영업외수익", 35, 0.0, 0.2),
    ("손익계산서", "영업외비용", "금융비용", "이자비용", 85, 0.0, 0.1),
    ("손익계산서", "영업외비용", "기타비용", "기타영업외비용", 45, 0.0, 0.2),

    ("손익계산서", "법인세", "법인세비용", "법인세비용", 300, 0.01, 0.05),

    ("재무상태표", "자산", "유동자산", "현금및현금성자산", 4000, 0.01, 0.05),
    ("재무상태표", "자산", "유동자산", "매출채권", 2700, 0.01, 0.04),
    ("재무상태표", "자산", "유동자산", "재고자산", 2000, 0.01, 0.05),
    ("재무상태표", "자산", "비유동자산", "유형자산", 9000, 0.005, 0.01),
    ("재무상태표", "자산", "비유동자산", "무형자산", 750, 0.0, 0.02),
    ("재무상태표", "자산", "비유동자산", "기타비유동자산", 550, 0.0, 0.05),

    ("재무상태표", "부채", "유동부채", "매입채무", 1700, 0.01, 0.05),
    ("재무상태표", "부채", "유동부채", "단기차입금", 2100, 0.0, 0.05),
    ("재무상태표", "부채", "비유동부채", "장기차입금", 3300, -0.005, 0.02),
    ("재무상태표", "부채", "비유동부채", "기타비유동부채", 650, 0.0, 0.05),

    ("재무상태표", "자본", "자본금", "자본금", 4800, 0.0, 0.0),
    ("재무상태표", "자본", "이익잉여금", "이익잉여금", 5900, 0.02, 0.03),
    ("재무상태표", "자본", "기타자본", "기타자본항목", 850, 0.0, 0.02),
]

# 법인별 규모 가중치(고정) : 법인마다 사업 규모가 다르다는 것을 반영
_raw_weights = {e: random.uniform(0.5, 10.0) for e in ENTITIES}
_weight_sum = sum(_raw_weights.values())
ENTITY_WEIGHTS = {e: w / _weight_sum for e, w in _raw_weights.items()}


def _consolidated_series(base: float, growth: float, vol: float, n: int) -> list:
    values = []
    v = base
    for _ in range(n):
        v = v * (1 + growth) * (1 + random.uniform(-vol, vol))
        values.append(v)
    return values


def _split_to_entities(target_total: float) -> dict:
    """연결 기준 금액(target_total)을 법인별로 나누고, 남는 차액을 연결조정으로 둔다.

    이렇게 하면 항상 (법인 20개 합산 + 연결조정) == target_total 이 정확히
    성립한다(연결조정이 내부거래 제거 등을 대표하는 '잔차'로 계산됨).
    """
    shares = {}
    for e in ENTITIES:
        noise = random.uniform(-0.05, 0.05)
        shares[e] = target_total * ENTITY_WEIGHTS[e] * (1 + noise)
    shares[ADJUSTMENT_ENTITY] = target_total - sum(shares.values())
    return shares


def _build_all_rows() -> pd.DataFrame:
    rows = []
    for statement_type, l1, l2, l3, base, growth, vol in LEAF_ACCOUNTS:
        series = _consolidated_series(base, growth, vol, len(PERIODS))
        for idx, (year, quarter) in enumerate(PERIODS):
            entity_amounts = _split_to_entities(series[idx])
            for entity, amount in entity_amounts.items():
                rows.append({
                    "year": year,
                    "quarter": quarter,
                    "statement_type": statement_type,
                    "법인": entity,
                    "대분류": l1,
                    "중분류": l2,
                    "세부계정": l3,
                    "금액": round(amount, 1),
                })
    return pd.DataFrame(rows)


def generate():
    config.RAW_DATA_DIR.mkdir(parents=True, exist_ok=True)
    df = _build_all_rows()

    for year, quarter in PERIODS:
        period_df = df[(df["year"] == year) & (df["quarter"] == quarter)]
        file_path = config.RAW_DATA_DIR / f"{year}_{quarter}Q_결산.xlsx"
        with pd.ExcelWriter(file_path, engine="openpyxl") as writer:
            for statement_type in ("손익계산서", "재무상태표"):
                sheet_df = period_df[period_df["statement_type"] == statement_type][
                    ["법인", "대분류", "중분류", "세부계정", "금액"]
                ]
                sheet_df.to_excel(writer, sheet_name=statement_type, index=False)
        print(f"생성됨: {file_path}")


def generate_budget_from_existing():
    """이미 만들어진 실적 파일(손익계산서+재무상태표, 법인별 상세)을 대분류
    기준으로 합산해서, 예산(계획) 파일을 별도로 만든다. 실제 회사에서도
    예산은 보통 법인/세부계정 단위가 아니라 대분류(매출/매출원가, 자산/부채/
    자본 등) 단위로 세우므로, 이 가상 예산도 같은 수준으로만 만든다.
    재무상태표 대분류도 포함해야 부채비율/ROE/ROA 같은 비율 지표의 예산
    대비 조회도 가능해진다(분자·분모 대분류가 모두 budget 테이블에 있어야
    query.get_budget_amount()의 ratio 재귀 계산이 성립하기 때문).

    실적 데이터를 만드는 random 스트림(모듈 상단의 random.seed(42))과
    겹치지 않도록, 별도의 random.Random 인스턴스를 쓴다 — 이 함수를 몇 번을
    다시 실행해도 이미 만들어둔 실적 수치는 전혀 건드리지 않는다.
    """
    rng = random.Random(2024)
    bias = {}
    for year, quarter in PERIODS:
        actual_path = config.RAW_DATA_DIR / f"{year}_{quarter}Q_결산.xlsx"
        if not actual_path.exists():
            print(f"[건너뜀] 실적 파일이 없어 예산을 만들 수 없습니다: {actual_path.name}")
            continue

        level1_sums = {}
        for sheet_name in ("손익계산서", "재무상태표"):
            sheet_df = pd.read_excel(actual_path, sheet_name=sheet_name)
            level1_sums.update(sheet_df.groupby("대분류")["금액"].sum().to_dict())

        budget_rows = []
        for level1, actual_amount in level1_sums.items():
            if level1 not in bias:
                bias[level1] = rng.uniform(0.92, 1.08)  # 대분류마다 계획을 보수적/낙관적으로 세우는 성향
            noise = rng.uniform(-0.03, 0.03)
            budget_amount = actual_amount * bias[level1] * (1 + noise)
            budget_rows.append({"대분류": level1, "금액": round(budget_amount, 1)})

        budget_path = config.RAW_DATA_DIR / f"{year}_{quarter}Q_예산.xlsx"
        with pd.ExcelWriter(budget_path, engine="openpyxl") as writer:
            pd.DataFrame(budget_rows).to_excel(writer, sheet_name="예산", index=False)
        print(f"생성됨: {budget_path}")


if __name__ == "__main__":
    generate()
    generate_budget_from_existing()
