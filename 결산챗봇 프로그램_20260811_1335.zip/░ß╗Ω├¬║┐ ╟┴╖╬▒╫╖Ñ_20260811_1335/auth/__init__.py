"""접속 인증 백엔드 팩토리.

llm/__init__.py의 get_llm_client()와 같은 구조: config.ACTIVE_AUTH_BACKEND
값으로 실제 구현을 고른다. 현재 기본값은 shared_password(공용 비밀번호
1개, 이름/사번은 로그 식별용 자기 기입)이고, 사내 LDAP/AD 연동이 준비되면
"ldap"로 바꾸기만 하면 된다 — app.py는 이 모듈의 check_credentials() /
using_default_password()만 호출하므로 백엔드를 바꿔도 app.py를 고칠
필요가 없다.
"""

import config

from .ldap_client import LDAPAuthBackend
from .shared_password import SharedPasswordAuth

_BACKENDS = {
    "shared_password": SharedPasswordAuth,
    "ldap": LDAPAuthBackend,
}


def get_auth_backend():
    backend_cls = _BACKENDS.get(config.ACTIVE_AUTH_BACKEND, SharedPasswordAuth)
    return backend_cls()


def check_credentials(identifier: str, password: str) -> bool:
    return get_auth_backend().check_credentials(identifier, password)


def using_default_password() -> bool:
    return get_auth_backend().using_default_password()
