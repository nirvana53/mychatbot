"""접속 인증 백엔드의 공통 인터페이스.

llm/base.py의 LLMClient와 같은 목적: app.py는 이 인터페이스에만 의존하고,
실제 구현(공용 비밀번호 / 사내 LDAP)은 config.ACTIVE_AUTH_BACKEND로 고른다.
"""

from abc import ABC, abstractmethod


class AuthBackend(ABC):
    @abstractmethod
    def check_credentials(self, identifier: str, password: str) -> bool:
        """identifier(이름/사번)와 password 조합이 유효하면 True.

        공용 비밀번호 백엔드는 identifier를 검증하지 않고(감사 로그 식별용
        자기 기입) password만 확인한다. LDAP 백엔드는 두 값을 모두 서버에
        검증받는다.
        """

    def using_default_password(self) -> bool:
        """공용 비밀번호가 아직 기본값(changeme)인지. 해당 없는 백엔드는 False."""
        return False
