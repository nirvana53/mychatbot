"""유연한 규칙 기반 질문 파서.

내부 AI agent LLM을 아직 연동할 수 없으므로, 정규식과 키워드 매칭으로
질문에서 기간(연도/분기, 상대 표현 포함)/법인/계정(3단계 트리 또는 계산
지표)과 사용자의 의도(intent)를 뽑아낸다. 고정된 문장 패턴을 강제하지
않도록, 절대 기간뿐 아니라 "이번분기", "작년" 같은 상대 표현과 다양한
동의어/줄임말을 함께 인식한다.

나중에 내부 AI agent가 연동되면, 이 모듈 대신(또는 이 모듈이 실패했을
때 보조로) LLM에게 직접 "질문 -> {intent, year, quarter, target, level,
entity}" JSON을 뽑아달라고 요청하는 방식으로 확장할 수 있다. chatbot.py는
parse_question()의 반환 형식만 지키면 되므로 내부 구현을 바꿔도 된다.
"""

import difflib
import re

ABSOLUTE_PERIOD_PATTERNS = [
    re.compile(r"(20\d{2})\s*년?\s*([1-4])\s*(?:분기|사분기|[qQ])"),
    re.compile(r"(\d{2})년\s*([1-4])\s*(?:분기|사분기|[qQ])"),
    re.compile(r"(20\d{2})\s*[-/]?\s*[qQ]\s*([1-4])"),
]

QUARTER_ONLY_PATTERN = re.compile(r"([1-4])\s*(?:분기|사분기)")

RELATIVE_CURRENT_Q = ["이번분기", "이번 분기", "당분기", "금분기", "최근분기", "최근 분기"]
RELATIVE_PREV_Q = ["저번분기", "저번 분기", "지난분기", "지난 분기", "전분기", "전 분기", "직전분기", "직전 분기"]
RELATIVE_CUR_YEAR = ["올해", "금년"]
RELATIVE_PREV_YEAR = ["작년", "전년", "지난해"]

LIST_ACCOUNTS_KEYWORDS = ["계정 목록", "계정목록", "어떤 계정", "계정 종류", "무슨 계정", "무슨 항목"]
COMPARE_KEYWORDS = ["비교", "대비", "차이", "얼마나 늘었", "얼마나 줄었", "보다 어때"]
TREND_KEYWORDS = ["추이", "트렌드", "흐름", "변화", "어떻게 변해", "그래프"]
BREAKDOWN_ENTITY_KEYWORDS = ["법인별", "법인 별", "회사별", "회사 별", "법인들"]
ANOMALY_KEYWORDS = ["이상치", "이상한", "특이한", "특이 법인", "튄", "튀는", "유독"]
NEW_ACCOUNT_KEYWORDS = ["새로 생긴", "새로생긴", "신규 계정", "신규계정", "새로운 계정", "새롭게 생긴", "처음 생긴", "새로 발생"]
BREAKDOWN_ACCOUNT_KEYWORDS = ["세부적으로", "세부항목", "항목별로", "항목 별로", "중분류별", "자세히"]

# 사용자가 흔히 줄여 부르는 표현 -> (실제 조회 대상, 레벨)
TARGET_ALIASES = {
    "순이익": ("당기순이익", "metric"),
    "총자산": ("자산", "level1"),
    "자산총계": ("자산", "level1"),
    "총부채": ("부채", "level1"),
    "부채총계": ("부채", "level1"),
    "총자본": ("자본", "level1"),
    "자본총계": ("자본", "level1"),
    "판관비": ("판매비와관리비", "level1"),
    "자기자본이익률": ("ROE", "ratio"),
    "자기자본수익률": ("ROE", "ratio"),
    "총자산이익률": ("ROA", "ratio"),
}

CONSOLIDATED_KEYWORDS = ["연결기준", "연결 기준", "전체 법인", "전사"]


def _extract_absolute_periods(question: str):
    periods = []
    for pattern in ABSOLUTE_PERIOD_PATTERNS:
        for y, q in pattern.findall(question):
            year = int(y)
            if year < 100:
                year += 2000
            periods.append((year, int(q)))
    return periods


def _extract_relative_periods(question: str, available_periods: list):
    if not available_periods:
        return []
    periods = []
    latest = available_periods[-1]
    latest_idx = len(available_periods) - 1

    if any(k in question for k in RELATIVE_CURRENT_Q):
        periods.append(latest)
    if any(k in question for k in RELATIVE_PREV_Q) and latest_idx >= 1:
        periods.append(available_periods[latest_idx - 1])

    q_match = QUARTER_ONLY_PATTERN.search(question)
    if any(k in question for k in RELATIVE_PREV_YEAR):
        quarter = int(q_match.group(1)) if q_match else latest[1]
        periods.append((latest[0] - 1, quarter))
    if any(k in question for k in RELATIVE_CUR_YEAR):
        quarter = int(q_match.group(1)) if q_match else latest[1]
        periods.append((latest[0], quarter))

    return periods


def _extract_periods(question: str, available_periods: list):
    periods = _extract_absolute_periods(question)
    periods += _extract_relative_periods(question, available_periods)
    # 중복 제거(순서 유지)
    seen = set()
    unique = []
    for p in periods:
        if p not in seen:
            seen.add(p)
            unique.append(p)
    return unique


def _normalize(text: str) -> str:
    """띄어쓰기 차이("영업 이익" vs "영업이익")를 무시하고 비교하기 위한 정규화."""
    return re.sub(r"\s+", "", text)


def _keyword_hit(keywords: list, question: str) -> bool:
    """키워드 자체에 공백이 있어도("신규 계정") 질문의 띄어쓰기 차이와 무관하게 매칭한다."""
    normalized_question = _normalize(question)
    return any(_normalize(kw) in normalized_question for kw in keywords)


def _fuzzy_contains(keyword: str, normalized_question: str, threshold: float = 0.75) -> bool:
    """오타를 허용하는 부분 문자열 매칭. 짧은 키워드는 오탐 위험이 커서 제외한다."""
    n = len(keyword)
    if n < 2:
        return False
    for window in (n - 1, n, n + 1):
        if window < 2:
            continue
        for i in range(len(normalized_question) - window + 1):
            segment = normalized_question[i:i + window]
            if difflib.SequenceMatcher(None, keyword, segment).ratio() >= threshold:
                return True
    return False


RANGE_PATTERN = re.compile(r"(.+?)부터\s*(.+?)까지")
YEAR_ONLY_PATTERN = re.compile(r"(20\d{2})\s*년")


def _extract_period_range(question: str, available_periods: list):
    """"2024년 1분기부터 2025년 2분기까지"처럼 범위로 지정된 추이 질문을 인식한다."""
    m = RANGE_PATTERN.search(question)
    if not m:
        return None
    start_text, end_text = m.group(1), m.group(2)

    start_periods = _extract_periods(start_text, available_periods)
    if not start_periods:
        y = YEAR_ONLY_PATTERN.search(start_text)
        if y:
            start_periods = [(int(y.group(1)), 1)]

    end_periods = _extract_periods(end_text, available_periods)
    if not end_periods:
        y = YEAR_ONLY_PATTERN.search(end_text)
        if y:
            year = int(y.group(1))
            quarters_in_year = [q for (yy, q) in available_periods if yy == year]
            end_periods = [(year, max(quarters_in_year) if quarters_in_year else 4)]

    if not start_periods or not end_periods:
        return None
    return start_periods[0], end_periods[0]


def _match_all_entities(question: str, known_entities: list):
    """질문에 등장하는 모든 법인명을 (등장 순서 유지 없이) 반환한다. 여러 법인을
    나란히 지정한 비교 질문("법인01이랑 법인02 비교해줘")을 감지하는 데 쓴다."""
    if any(k in question for k in CONSOLIDATED_KEYWORDS):
        return []
    normalized = _normalize(question)
    return [e for e in sorted(known_entities, key=len, reverse=True) if e and e in normalized]


def _match_entity(question: str, known_entities: list):
    matches = _match_all_entities(question, known_entities)
    if matches:
        return matches[0]
    if any(k in question for k in CONSOLIDATED_KEYWORDS):
        return None
    normalized = _normalize(question)
    for entity in sorted(known_entities, key=len, reverse=True):
        if entity and _fuzzy_contains(entity, normalized):
            return entity
    return None


def _match_target(question: str, known_accounts: dict):
    candidates = []
    for name in known_accounts.get("ratios", []):
        candidates.append((name, name, "ratio"))
    for name in known_accounts.get("metrics", []):
        candidates.append((name, name, "metric"))
    for name in known_accounts.get("level3", []):
        candidates.append((name, name, "level3"))
    for name in known_accounts.get("level2", []):
        candidates.append((name, name, "level2"))
    for name in known_accounts.get("level1", []):
        candidates.append((name, name, "level1"))
    for alias, (target, level) in TARGET_ALIASES.items():
        candidates.append((alias, target, level))

    candidates.sort(key=lambda c: len(c[0]), reverse=True)
    normalized = _normalize(question)
    for keyword, target, level in candidates:
        if keyword and keyword in normalized:
            return target, level
    for keyword, target, level in candidates:
        if keyword and _fuzzy_contains(keyword, normalized):
            return target, level
    return None, None


def parse_question(question: str, known_accounts: dict, known_entities: list = None,
                    available_periods: list = None, followup_context: dict = None) -> dict:
    question = question.strip()
    known_entities = known_entities or []
    available_periods = available_periods or []
    followup_context = followup_context or {}

    if any(kw in question for kw in LIST_ACCOUNTS_KEYWORDS):
        return {"intent": "list_accounts"}

    periods = _extract_periods(question, available_periods)
    entities_multi = _match_all_entities(question, known_entities)
    entity = entities_multi[0] if entities_multi else _match_entity(question, known_entities)
    target, level = _match_target(question, known_accounts)

    if target is None:
        # 특정 계정명 없이 "계정" 자체를 대상으로 스캔하는 질문들(신규 계정, 계정 단위
        # 이상치)은 대상 계정을 못 찾아도 처리할 수 있으므로 unresolved 처리 전에 먼저 본다.
        if _keyword_hit(NEW_ACCOUNT_KEYWORDS, question):
            year, quarter = (periods[0] if periods else (available_periods[-1] if available_periods else (None, None)))
            if year is None:
                return {"intent": "unresolved", "reason": "no_period"}
            return {"intent": "new_accounts", "year": year, "quarter": quarter, "entity": entity}

        if _keyword_hit(ANOMALY_KEYWORDS, question):
            year, quarter = (periods[0] if periods else (available_periods[-1] if available_periods else (None, None)))
            if year is None:
                return {"intent": "unresolved", "reason": "no_period"}
            return {"intent": "account_anomaly", "year": year, "quarter": quarter, "entity": entity}

        # 이전에 다루던 계정을 그대로 이어받는 후속 질문("2025년 1분기랑 비교해줘")
        if followup_context.get("target") and followup_context.get("year") is not None and periods:
            target = followup_context["target"]
            level = followup_context["level"]
            if entity is None:
                entity = followup_context.get("entity")
            base_period = (followup_context["year"], followup_context["quarter"])
            new_period = periods[0]
            if base_period == new_period:
                return {"intent": "single", "year": new_period[0], "quarter": new_period[1], "target": target, "level": level, "entity": entity}
            period_a, period_b = sorted([base_period, new_period])
            return {
                "intent": "compare", "target": target, "level": level, "entity": entity,
                "period_a": period_a, "period_b": period_b,
            }

        return {"intent": "unresolved", "reason": "no_account"}

    if len(entities_multi) >= 2:
        year, quarter = (periods[0] if periods else (available_periods[-1] if available_periods else (None, None)))
        if year is None:
            return {"intent": "unresolved", "reason": "no_period"}
        return {
            "intent": "compare_entities", "year": year, "quarter": quarter,
            "target": target, "level": level, "entities": entities_multi,
        }

    if any(kw in question for kw in BREAKDOWN_ENTITY_KEYWORDS) or any(kw in question for kw in ANOMALY_KEYWORDS):
        year, quarter = (periods[0] if periods else (available_periods[-1] if available_periods else (None, None)))
        if year is None:
            return {"intent": "unresolved", "reason": "no_period"}
        outlier_only = any(kw in question for kw in ANOMALY_KEYWORDS)
        return {
            "intent": "breakdown_entity", "year": year, "quarter": quarter,
            "target": target, "level": level, "outlier_only": outlier_only,
        }

    if any(kw in question for kw in BREAKDOWN_ACCOUNT_KEYWORDS) and level in ("level1", "level2"):
        year, quarter = (periods[0] if periods else (available_periods[-1] if available_periods else (None, None)))
        if year is None:
            return {"intent": "unresolved", "reason": "no_period"}
        return {
            "intent": "breakdown_account", "year": year, "quarter": quarter,
            "target": target, "level": level, "entity": entity,
        }

    period_range = _extract_period_range(question, available_periods)
    if period_range:
        period_start, period_end = sorted(period_range)
        return {
            "intent": "trend", "target": target, "level": level, "entity": entity,
            "period_start": period_start, "period_end": period_end,
        }

    if len(periods) >= 2:
        period_a, period_b = sorted(periods[:2])  # 과거 -> 최근 순으로 비교해야 증감 방향이 직관적으로 읽힌다
        return {
            "intent": "compare", "target": target, "level": level, "entity": entity,
            "period_a": period_a, "period_b": period_b,
        }

    if any(kw in question for kw in TREND_KEYWORDS) or not periods:
        year_filter = periods[0][0] if periods else None
        return {"intent": "trend", "target": target, "level": level, "entity": entity, "year": year_filter}

    year, quarter = periods[0]
    return {"intent": "single", "year": year, "quarter": quarter, "target": target, "level": level, "entity": entity}
