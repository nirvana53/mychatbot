"""data/raw 폴더의 연결결산 엑셀/CSV 파일을 읽어 SQLite DB로 적재한다.

사용자는 분기별 결산 파일(엑셀 또는 CSV)을 data/raw 폴더에 넣기만 하면
된다. 이 스크립트를 실행하면 파일을 읽어서 조회하기 쉬운 하나의 표
(financial_statements 테이블)로 합쳐 data/finance.db에 저장한다.

데이터는 3단계 계정트리(대분류-중분류-세부계정)와 법인(entity) 정보를
함께 저장한다. 법인 컬럼이 없는 파일(예: 법인 구분 없이 연결 수치만 있는
파일)을 넣으면 entity를 "연결"로 채워서 적재하므로, 법인별 데이터가 아직
없어도 동작한다.

파일 이름에서 연도/분기를 자동으로 추출한다. 예: "2024_1Q_결산.xlsx",
"2024년 3분기 결산.xlsx" 등. 실제 파일명 규칙이 다르면 _extract_period
함수의 정규식만 조정하면 된다.

시트/파일의 컬럼명이 정확히 '법인/대분류/중분류/세부계정/금액'이 아니어도,
비슷한 이름이면 자동으로 인식한다. 인식이 안 되면 아래 *_KEYWORDS
목록을 조정한다.

실행:
    python -m data_pipeline.ingest
"""

import re
import sqlite3
from datetime import datetime, timezone

import pandas as pd

import config
from query_engine import query

ENTITY_KEYWORDS = ["법인", "entity", "회사명", "회사"]
LEVEL1_KEYWORDS = ["대분류", "level1", "구분"]
LEVEL2_KEYWORDS = ["중분류", "level2"]
LEVEL3_KEYWORDS = ["세부계정", "계정명", "항목", "level3", "account"]
AMOUNT_KEYWORDS = ["금액", "amount", "value"]

DEFAULT_ENTITY = "연결"
BUDGET_FILE_KEYWORDS = ["예산", "budget", "계획"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS financial_statements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    year INTEGER NOT NULL,
    quarter INTEGER NOT NULL,
    statement_type TEXT NOT NULL,
    entity TEXT NOT NULL,
    level1 TEXT NOT NULL,
    level2 TEXT,
    level3 TEXT,
    amount REAL NOT NULL,
    unit TEXT DEFAULT '백만원',
    source_file TEXT,
    ingested_at TEXT
);
"""

# 예산(계획)은 실적과 달리 법인/세부계정 단위가 아니라 대분류 단위로만
# 관리한다고 가정한다(실제 회사 예산 프로세스도 보통 이 정도 단위로 세운다).
BUDGET_SCHEMA = """
CREATE TABLE IF NOT EXISTS budget (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    year INTEGER NOT NULL,
    quarter INTEGER NOT NULL,
    level1 TEXT NOT NULL,
    amount REAL NOT NULL,
    unit TEXT DEFAULT '백만원',
    source_file TEXT,
    ingested_at TEXT
);
"""


def _is_budget_file(filename: str) -> bool:
    lower = filename.lower()
    return any(kw.lower() in lower for kw in BUDGET_FILE_KEYWORDS)


def _find_column(columns, keywords):
    for col in columns:
        col_str = str(col).strip().lower()
        for kw in keywords:
            if kw.lower() in col_str:
                return col
    return None


def _extract_period(filename: str):
    year_match = re.search(r"(20\d{2})", filename)
    quarter_match = re.search(r"([1-4])\s*[qQ분기]", filename)
    year = int(year_match.group(1)) if year_match else None
    quarter = int(quarter_match.group(1)) if quarter_match else None
    return year, quarter


def _guess_statement_type(sheet_name: str, filename: str) -> str:
    combined = f"{sheet_name} {filename}"
    if "손익" in combined:
        return "손익계산서"
    if "재무상태" in combined or "재무" in combined:
        return "재무상태표"
    return sheet_name or "결산"


def _read_sheet_as_rows(df: pd.DataFrame, year, quarter, statement_type, source_file):
    entity_col = _find_column(df.columns, ENTITY_KEYWORDS)
    level1_col = _find_column(df.columns, LEVEL1_KEYWORDS)
    level2_col = _find_column(df.columns, LEVEL2_KEYWORDS)
    level3_col = _find_column(df.columns, LEVEL3_KEYWORDS)
    amount_col = _find_column(df.columns, AMOUNT_KEYWORDS)

    if level1_col is None or amount_col is None:
        print(f"  [건너뜀] {source_file} 시트에서 대분류/금액 컬럼을 찾지 못했습니다: {list(df.columns)}")
        return []

    rows = []
    now = datetime.now(timezone.utc).isoformat()
    for _, r in df.iterrows():
        level1 = r.get(level1_col)
        amount = r.get(amount_col)
        if pd.isna(level1) or pd.isna(amount):
            continue

        entity = r.get(entity_col) if entity_col else None
        entity = str(entity).strip() if entity is not None and not pd.isna(entity) else DEFAULT_ENTITY

        level2 = r.get(level2_col) if level2_col else None
        level2 = str(level2).strip() if level2 is not None and not pd.isna(level2) else None

        level3 = r.get(level3_col) if level3_col else None
        level3 = str(level3).strip() if level3 is not None and not pd.isna(level3) else None

        rows.append((
            year,
            quarter,
            statement_type,
            entity,
            str(level1).strip(),
            level2,
            level3,
            float(amount),
            "백만원",
            source_file,
            now,
        ))
    return rows


def _load_file(path) -> list:
    year, quarter = _extract_period(path.name)
    if year is None or quarter is None:
        print(f"  [건너뜀] 파일명에서 연도/분기를 인식할 수 없습니다: {path.name}")
        return []

    all_rows = []
    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
        statement_type = _guess_statement_type("", path.name)
        all_rows.extend(_read_sheet_as_rows(df, year, quarter, statement_type, path.name))
    else:
        sheets = pd.read_excel(path, sheet_name=None)
        for sheet_name, df in sheets.items():
            statement_type = _guess_statement_type(sheet_name, path.name)
            all_rows.extend(_read_sheet_as_rows(df, year, quarter, statement_type, path.name))
    return all_rows


def _read_budget_sheet_as_rows(df: pd.DataFrame, year, quarter, source_file):
    level1_col = _find_column(df.columns, LEVEL1_KEYWORDS)
    amount_col = _find_column(df.columns, AMOUNT_KEYWORDS)
    if level1_col is None or amount_col is None:
        print(f"  [건너뜀] {source_file} 시트에서 대분류/금액 컬럼을 찾지 못했습니다: {list(df.columns)}")
        return []

    rows = []
    now = datetime.now(timezone.utc).isoformat()
    for _, r in df.iterrows():
        level1 = r.get(level1_col)
        amount = r.get(amount_col)
        if pd.isna(level1) or pd.isna(amount):
            continue
        rows.append((year, quarter, str(level1).strip(), float(amount), "백만원", source_file, now))
    return rows


def _load_budget_file(path) -> list:
    year, quarter = _extract_period(path.name)
    if year is None or quarter is None:
        print(f"  [건너뜀] 파일명에서 연도/분기를 인식할 수 없습니다: {path.name}")
        return []

    all_rows = []
    if path.suffix.lower() == ".csv":
        df = pd.read_csv(path)
        all_rows.extend(_read_budget_sheet_as_rows(df, year, quarter, path.name))
    else:
        sheets = pd.read_excel(path, sheet_name=None)
        for _, df in sheets.items():
            all_rows.extend(_read_budget_sheet_as_rows(df, year, quarter, path.name))
    return all_rows


ENTITY_PATTERN = re.compile(r"^법인\d{2}$")


def validate_integrity(conn) -> list:
    """"법인 20개 합산 + 연결조정 = 연결"이라는 전제가 실제 적재 데이터에서도
    성립하는지 점검한다. 연결은 저장된 행이 아니라 항상 전체 법인 합산으로
    계산되므로(별도 총계 대사가 아니라), 여기서는 그 계산이 왜곡되지 않도록
    법인 구성 자체가 온전한지(개수/중복/의도치 않은 "연결" 행 혼입)를 본다.
    """
    warnings = []

    periods = conn.execute(
        "SELECT DISTINCT year, quarter FROM financial_statements ORDER BY year, quarter"
    ).fetchall()
    for year, quarter in periods:
        entities = [r[0] for r in conn.execute(
            "SELECT DISTINCT entity FROM financial_statements WHERE year=? AND quarter=?", (year, quarter)
        ).fetchall()]
        entity_like = [e for e in entities if ENTITY_PATTERN.match(e)]
        has_adjustment = "연결조정" in entities
        has_consolidated_row = DEFAULT_ENTITY in entities

        if has_consolidated_row and entity_like:
            warnings.append(
                f"{year}년 {quarter}분기: 법인별 데이터와 '{DEFAULT_ENTITY}' 행이 함께 있습니다. "
                "연결 기준 조회는 법인 전체를 합산하므로 중복 집계될 수 있습니다(원본 파일의 법인 컬럼 확인 필요)."
            )
        if entity_like and not has_adjustment:
            warnings.append(f"{year}년 {quarter}분기: 법인별 데이터는 있지만 '연결조정' 행이 없습니다.")
        if entity_like and len(entity_like) != 20:
            warnings.append(
                f"{year}년 {quarter}분기: 법인이 {len(entity_like)}개 확인됩니다(예상 20개). "
                "일부 법인 데이터가 빠졌거나 중복 코드가 있을 수 있습니다."
            )
        unexpected = [e for e in entities if e not in entity_like and e not in (DEFAULT_ENTITY, "연결조정")]
        if unexpected:
            warnings.append(f"{year}년 {quarter}분기: 예상 형식(법인NN/연결조정)과 다른 법인명이 있습니다: {', '.join(unexpected)}")

    dup_count = conn.execute(
        """SELECT COUNT(*) FROM (
             SELECT year, quarter, entity, level1, level2, level3, COUNT(*) c
             FROM financial_statements
             GROUP BY year, quarter, entity, level1, level2, level3
             HAVING c > 1
           )"""
    ).fetchone()[0]
    if dup_count:
        warnings.append(f"동일한 (연도, 분기, 법인, 계정) 조합이 중복 적재된 행이 {dup_count}건 있습니다.")

    return warnings


def ingest() -> dict:
    config.RAW_DATA_DIR.mkdir(parents=True, exist_ok=True)
    files = [
        p for p in config.RAW_DATA_DIR.iterdir()
        if p.suffix.lower() in (".xlsx", ".xls", ".csv") and not p.name.startswith("~$")
    ]
    if not files:
        print(f"data/raw 폴더에 결산 파일이 없습니다: {config.RAW_DATA_DIR}")
        return {"total_rows": 0, "budget_rows": 0, "warnings": []}

    budget_files = [p for p in files if _is_budget_file(p.name)]
    statement_files = [p for p in files if p not in budget_files]

    conn = sqlite3.connect(config.DB_PATH)
    try:
        conn.execute("DROP TABLE IF EXISTS financial_statements")
        conn.execute(SCHEMA)
        conn.execute("DROP TABLE IF EXISTS budget")
        conn.execute(BUDGET_SCHEMA)

        total_rows = 0
        for path in sorted(statement_files):
            print(f"읽는 중: {path.name}")
            rows = _load_file(path)
            conn.executemany(
                """INSERT INTO financial_statements
                   (year, quarter, statement_type, entity, level1, level2, level3,
                    amount, unit, source_file, ingested_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                rows,
            )
            total_rows += len(rows)
            print(f"  -> {len(rows)}건 적재")

        budget_rows = 0
        for path in sorted(budget_files):
            print(f"읽는 중(예산): {path.name}")
            rows = _load_budget_file(path)
            conn.executemany(
                "INSERT INTO budget (year, quarter, level1, amount, unit, source_file, ingested_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                rows,
            )
            budget_rows += len(rows)
            print(f"  -> {len(rows)}건 적재(예산)")
        conn.commit()

        warnings = validate_integrity(conn)
        print(f"완료: 실적 {total_rows}건, 예산 {budget_rows}건을 {config.DB_PATH}에 적재했습니다.")
        for w in warnings:
            print(f"  [경고] {w}")
        return {"total_rows": total_rows, "budget_rows": budget_rows, "warnings": warnings}
    finally:
        conn.close()
        query.clear_cache()


if __name__ == "__main__":
    ingest()
