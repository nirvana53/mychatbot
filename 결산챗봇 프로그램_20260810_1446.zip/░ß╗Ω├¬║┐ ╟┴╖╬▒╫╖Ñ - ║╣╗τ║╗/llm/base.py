"""LLM 클라이언트 공통 인터페이스.

지금은 Mock 구현만 있지만, 나중에 회사 내부 AI agent API를 붙일 때는
LLMClient를 상속한 새 클래스 하나만 추가하면 된다(InternalAgentLLMClient가
그 예시이자 자리표시자다). 챗봇 로직(chatbot.py)은 이 인터페이스에만
의존하므로 백엔드를 바꿔도 다른 코드는 수정할 필요가 없다.
"""

from abc import ABC, abstractmethod


class LLMClient(ABC):
    @abstractmethod
    def generate_answer(self, question: str, context: dict) -> str:
        """사용자 질문과 조회된 결산 데이터(context)를 받아 자연어 답변을 만든다.

        Args:
            question: 사용자가 입력한 원본 질문.
            context: query_engine이 SQLite에서 조회한 결과와 부가 정보.
                예) {"intent": "single", "rows": [...], "matched_accounts": [...]}

        Returns:
            사용자에게 보여줄 답변 문자열.
        """
        raise NotImplementedError
