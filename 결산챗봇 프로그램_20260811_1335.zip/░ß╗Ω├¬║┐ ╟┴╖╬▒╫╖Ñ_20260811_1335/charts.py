"""추이/브레이크다운/비교 답변에 곁들이는 차트.

단일 지표를 시간(추이) 또는 범주(법인/세부계정 브레이크다운)로 보여주는
것이므로 항상 값이 하나뿐인 단일 시리즈 차트다. 그래서 범례 없이 하나의
파란색(연결결산 데이터에는 없는, 데이터 시각화용 강조색)만 사용하고,
얇은 선/막대와 은은한 격자선, 툴팁으로 정보를 보여준다. 법인별 이상치나
두 시점 비교의 증감처럼 "일반값과 다른 무언가"를 짚어주는 차트만 예외적으로
상태색(경고색)이나 증가/감소 두 색(diverging)을 추가로 쓴다.

색상 값은 dataviz 스킬의 palette.md를 그대로 따른다(카테고리 슬롯1 blue,
슬롯8 red, 상태색 warning). 모든 차트 함수는 `dark` 인자로 라이트/다크
색상 세트를 고른다 — Streamlit이 다크 테마일 때 흰 배경 차트가 튀어 보이는
것을 막기 위해 배경색도 함께 지정한다. 상태색(warning)과 축/라벨 잉크
(muted)는 palette.md에서 이미 라이트/다크 공통값으로 정의되어 있어 그대로 쓴다.
"""

import altair as alt
import pandas as pd

MUTED = "#898781"   # 축/라벨 잉크. 라이트/다크 공통값(palette.md)
WARNING = "#fab219"  # 상태색. 라이트/다크 공통값(palette.md, "고정 — 테마 없음")

_LIGHT = {
    "blue": "#2a78d6", "orange": "#eb6834", "aqua": "#1baf7a", "red": "#e34948",
    "grid": "#e1e0d9", "axis": "#c3c2b7", "surface": "#fcfcfb",
}
_DARK = {
    "blue": "#3987e5", "orange": "#d95926", "aqua": "#199e70", "red": "#e66767",
    "grid": "#2c2c2a", "axis": "#383835", "surface": "#1a1a19",
}
_CATEGORICAL_ORDER = ["blue", "orange", "aqua"]  # palette.md 슬롯 1~3(all-pairs 검증된 구간)까지만 사용


def _palette(dark: bool) -> dict:
    return _DARK if dark else _LIGHT


def _axis_styles(p: dict):
    axis_x = dict(labelColor=MUTED, titleColor=MUTED, domainColor=p["axis"], gridColor=p["grid"])
    axis_y = dict(labelColor=MUTED, domainColor=p["axis"])
    return axis_x, axis_y


def _trend_layers(rows: list, label: str, unit: str, p: dict) -> alt.LayerChart:
    """trend_line_chart의 레이어만 만들고 top-level config는 붙이지 않는다.

    Vega-Lite는 vconcat/hconcat의 자식 스펙에 config(예: configure_view)가
    붙어 있으면 거부하므로, small-multiples(multi_trend_chart)에서 재사용할
    수 있도록 config를 붙이는 단계를 분리해둔다.
    """
    axis_x, axis_y = _axis_styles(p)
    df = pd.DataFrame(rows)
    df["분기"] = df.apply(lambda r: f"{r['year']}.{r['quarter']}Q", axis=1)
    order = df["분기"].tolist()

    base = alt.Chart(df).encode(
        x=alt.X("분기:N", sort=order, title="분기", axis=alt.Axis(**axis_x)),
        y=alt.Y("amount:Q", title=f"{label} ({unit})", axis=alt.Axis(**axis_y)),
        tooltip=[
            alt.Tooltip("분기:N", title="분기"),
            alt.Tooltip("amount:Q", title=label, format=",.0f"),
        ],
    )
    line = base.mark_line(color=p["blue"], strokeWidth=2)
    points = base.mark_circle(color=p["blue"], size=50)

    # 가장 최근 분기는 "지금 보고 있는 시점"이라는 의미로 점을 키워서 강조한다.
    latest = base.transform_filter(alt.FieldEqualPredicate(field="분기", equal=order[-1])).mark_circle(color=p["blue"], size=130)

    # 값을 눈으로 바로 읽을 수 있도록 시작/끝 지점에만 숫자를 직접 표시한다
    # (점마다 라벨을 달면 지저분해지므로 선택적으로만 표시).
    endpoints = df.iloc[[0, -1]] if len(df) >= 2 else df
    labels = alt.Chart(endpoints).mark_text(dy=-14, color=MUTED, fontSize=11).encode(
        x=alt.X("분기:N", sort=order),
        y=alt.Y("amount:Q"),
        text=alt.Text("amount:Q", format=",.0f"),
    )
    return line + points + latest + labels


def trend_line_chart(rows: list, label: str, unit: str, dark: bool = False) -> alt.Chart:
    p = _palette(dark)
    return _trend_layers(rows, label, unit, p).properties(height=260, background=p["surface"]).configure_view(strokeWidth=0)


def breakdown_bar_chart(rows: list, label: str, unit: str, highlight_labels: list = None, dark: bool = False) -> alt.Chart:
    """법인별/세부계정별 브레이크다운 바차트.

    highlight_labels를 주면 해당 항목(예: 이상치로 감지된 법인)만 경고색으로
    구분하고 범례를 붙인다. 항목이 많을 때(전체 법인 20개 등)는 막대 끝
    직접 라벨을 생략해 툴팁으로만 값을 확인하게 한다(라벨 과밀 방지).
    """
    p = _palette(dark)
    axis_x, axis_y = _axis_styles(p)
    df = pd.DataFrame(rows)
    highlight_labels = set(highlight_labels or [])
    show_direct_labels = len(df) <= 12

    if highlight_labels:
        df["구분"] = df["label"].apply(lambda v: "이상치" if v in highlight_labels else "일반")
        color = alt.Color(
            "구분:N",
            scale=alt.Scale(domain=["일반", "이상치"], range=[p["blue"], WARNING]),
            legend=alt.Legend(title=None, orient="top"),
        )
    else:
        df["구분"] = "일반"
        color = alt.value(p["blue"])

    chart = alt.Chart(df).mark_bar(cornerRadiusEnd=3).encode(
        x=alt.X("amount:Q", title=f"{label} ({unit})", axis=alt.Axis(**axis_x)),
        y=alt.Y("label:N", sort="-x", title=None, axis=alt.Axis(**axis_y)),
        color=color,
        tooltip=[
            alt.Tooltip("label:N", title="구분"),
            alt.Tooltip("amount:Q", title=label, format=",.0f"),
        ],
    )
    height = max(120, 22 * len(df))
    if not show_direct_labels:
        return chart.properties(height=height, background=p["surface"]).configure_view(strokeWidth=0)

    value_labels = alt.Chart(df).mark_text(align="left", dx=4, color=MUTED, fontSize=11).encode(
        x=alt.X("amount:Q"),
        y=alt.Y("label:N", sort="-x"),
        text=alt.Text("amount:Q", format=",.0f"),
    )
    return (chart + value_labels).properties(height=height, background=p["surface"]).configure_view(strokeWidth=0)


def entity_trend_matrix_chart(rows: list, label: str, unit: str, highlight_entities: list, dark: bool = False) -> alt.Chart:
    """법인×분기 매트릭스를 여러 개의 선으로 겹쳐 보여준다("매출 매트릭스로
    보여줘").

    법인이 20개+연결조정이라 전부 다른 색을 주면(팔레트 슬롯이 부족해서)
    구분이 안 되고 범례도 못 쓴다. 그래서 규모가 큰 상위 3개 법인만
    palette.md 카테고리 슬롯 1~3(all-pairs 검증된 구간)로 강조하고, 나머지는
    "기타 법인"이라는 이름의 흐린 배경 선으로 접어서 전체 분포는 보이되
    식별은 상위 3개만 하도록 한다(dataviz 스킬: 3개 넘으면 Other로 폴드).
    """
    p = _palette(dark)
    axis_x, axis_y = _axis_styles(p)
    df = pd.DataFrame(rows)
    df["분기"] = df.apply(lambda r: f"{r['year']}.{r['quarter']}Q", axis=1)
    order = sorted(df["분기"].unique(), key=lambda s: tuple(int(x.rstrip("Q")) for x in s.split(".")))

    highlight_entities = list(highlight_entities)
    highlight_set = set(highlight_entities)
    df["구분"] = df["entity"].apply(lambda e: e if e in highlight_set else "기타 법인")

    domain = highlight_entities + ["기타 법인"]
    color_range = [p[c] for c in _CATEGORICAL_ORDER[: len(highlight_entities)]] + [p["axis"]]

    chart = alt.Chart(df).mark_line(strokeWidth=1.8).encode(
        x=alt.X("분기:N", sort=order, title="분기", axis=alt.Axis(**axis_x)),
        y=alt.Y("amount:Q", title=f"{label} ({unit})", axis=alt.Axis(**axis_y)),
        color=alt.Color("구분:N", scale=alt.Scale(domain=domain, range=color_range), legend=alt.Legend(title=None, orient="top")),
        detail=alt.Detail("entity:N"),  # "기타 법인"이 하나로 뭉개지지 않고 각자 선으로 남게 함
        opacity=alt.condition(alt.FieldEqualPredicate(field="구분", equal="기타 법인"), alt.value(0.35), alt.value(1.0)),
        tooltip=[
            alt.Tooltip("entity:N", title="법인"),
            alt.Tooltip("분기:N", title="분기"),
            alt.Tooltip("amount:Q", title=label, format=",.0f"),
        ],
    )
    return chart.properties(height=320, background=p["surface"]).configure_view(strokeWidth=0)


def multi_trend_chart(series: list, dark: bool = False) -> alt.VConcatChart:
    """지표를 2개 이상 동시에 물었을 때("매출이랑 영업이익 추이 같이 보여줘")
    쓰는 small-multiples. 지표마다 단위(백만원/%)가 다를 수 있어 한 축을
    공유하지 않고(y='independent') 세로로 쌓은 미니 차트 여러 개로 보여준다.
    """
    p = _palette(dark)
    charts = [
        _trend_layers(s["rows"], s["target"], s["unit"], p).properties(height=160, title=s["target"])
        for s in series
        if s.get("rows")
    ]
    return alt.vconcat(*charts).resolve_scale(y="independent").properties(background=p["surface"]).configure_view(strokeWidth=0)


def diverging_bar_chart(rows: list, label: str, unit: str, dark: bool = False) -> alt.Chart:
    """두 시점 비교에서 변동에 가장 크게 기여한 세부계정을 증가/감소로 나눠 보여준다.

    증가(파란색)와 감소(빨간색)라는 극(polarity)이 있는 데이터라 diverging
    두 색 인코딩을 쓴다(dataviz 스킬: 발산형은 두 색 + 중립 회색).
    """
    p = _palette(dark)
    axis_x, axis_y = _axis_styles(p)
    df = pd.DataFrame(rows)
    df["방향"] = df["diff"].apply(lambda v: "증가" if v > 0 else ("감소" if v < 0 else "변동없음"))
    sort_field = alt.EncodingSortField(field="diff", order="descending")

    chart = alt.Chart(df).mark_bar(cornerRadiusEnd=3).encode(
        x=alt.X("diff:Q", title=f"변동 ({unit})", axis=alt.Axis(**axis_x)),
        y=alt.Y("label:N", sort=sort_field, title=None, axis=alt.Axis(**axis_y)),
        color=alt.Color(
            "방향:N",
            scale=alt.Scale(domain=["증가", "감소", "변동없음"], range=[p["blue"], p["red"], p["axis"]]),
            legend=alt.Legend(title=None, orient="top"),
        ),
        tooltip=[
            alt.Tooltip("label:N", title="세부계정"),
            alt.Tooltip("diff:Q", title="변동", format="+,.0f"),
        ],
    )
    # 막대가 0을 기준으로 양쪽에 그려지므로, 양수/음수 라벨을 각각 막대 바깥쪽에 붙인다.
    label_base = alt.Chart(df).encode(
        x=alt.X("diff:Q"), y=alt.Y("label:N", sort=sort_field), text=alt.Text("diff:Q", format="+,.0f"),
    )
    positive_labels = label_base.transform_filter("datum.diff >= 0").mark_text(align="left", dx=4, color=MUTED, fontSize=11)
    negative_labels = label_base.transform_filter("datum.diff < 0").mark_text(align="right", dx=-4, color=MUTED, fontSize=11)

    height = max(120, 26 * len(df))
    return (chart + positive_labels + negative_labels).properties(height=height, background=p["surface"]).configure_view(strokeWidth=0)
