"""Mock LLM 클라이언트.

회사 내부 AI agent API를 아직 연결할 수 없는 현재 단계에서 사용하는
임시 구현이다. 실제 LLM을 호출하지 않고, query_engine이 SQLite에서
조회해 온 결과(context)를 규칙 기반 템플릿으로 자연어 문장으로
바꿔주기만 한다. 오프라인으로 동작하므로 데이터가 외부로 나가지 않는다.

내부 AI agent 연동 후에는 이 클래스 대신 InternalAgentLLMClient가
context를 프롬프트에 담아 실제 LLM에게 답변 문장을 맡기게 되므로,
지금보다 더 자연스러운 답변(설명, 요약, 비교 해설 등)이 가능해진다.
"""

from .base import LLMClient


def _fmt(amount: float, unit: str) -> str:
    if unit == "%":
        return f"{amount:,.1f}{unit}"
    return f"{amount:,.0f}{unit}"


def _entity_label(entity) -> str:
    return entity if entity else "연결"


class MockLLMClient(LLMClient):
    def generate_answer(self, question: str, context: dict) -> str:
        intent = context.get("intent")
        handler = getattr(self, f"_handle_{intent}", None)
        if handler is None:
            return self._handle_unresolved(question, context)
        return handler(question, context)

    def _handle_single(self, question: str, context: dict) -> str:
        entity_label = _entity_label(context.get("entity"))
        if not context.get("found"):
            return (
                f"{context.get('year')}년 {context.get('quarter')}분기 "
                f"{entity_label} 기준 '{context.get('target')}' 데이터를 찾지 못했습니다. "
                "연도/분기 표기나 계정명을 다시 확인해 주세요."
            )
        amount = _fmt(context["amount"], context.get("unit", "백만원"))
        text = (
            f"{context['year']}년 {context['quarter']}분기 {entity_label} 기준 "
            f"'{context['target']}'은 {amount}입니다."
        )
        change_line = self._format_changes(context.get("changes"), context.get("unit", "백만원"))
        if change_line:
            text += "\n" + change_line
        return text

    def _format_changes(self, changes: dict | None, unit: str) -> str:
        if not changes:
            return ""
        parts = []
        if changes.get("qoq") and changes["qoq"].get("diff") is not None:
            parts.append(self._change_phrase("전분기 대비", changes["qoq"], unit))
        if changes.get("yoy") and changes["yoy"].get("diff") is not None:
            parts.append(self._change_phrase("전년 동기 대비", changes["yoy"], unit))
        return " / ".join(parts)

    def _change_phrase(self, label: str, cmp: dict, unit: str) -> str:
        diff = cmp["diff"]
        direction = "증가" if diff > 0 else ("감소" if diff < 0 else "변동 없음")
        if unit == "%":
            # 비율 지표는 상대 변화율(%) 대신 %p(퍼센트포인트) 차이만 보여줘야 헷갈리지 않는다
            return f"({label} {abs(diff):.1f}%p {direction})"
        pct = cmp.get("pct_change")
        pct_str = f", {pct:+.1f}%" if pct is not None else ""
        return f"({label} {_fmt(abs(diff), unit)} {direction}{pct_str})"

    def _handle_trend(self, question: str, context: dict) -> str:
        rows = context.get("rows", [])
        entity_label = _entity_label(context.get("entity"))
        if not rows:
            return f"{entity_label} 기준 '{context.get('target')}'에 대한 시계열 데이터가 없습니다."
        unit = context.get("unit", "백만원")
        lines = [
            f"- {r['year']}년 {r['quarter']}분기: {_fmt(r['amount'], unit)}"
            for r in rows
        ]
        header = f"{entity_label} 기준 '{context['target']}' 분기별 추이입니다. (그래프 참고)\n"
        return header + "\n".join(lines)

    def _handle_compare(self, question: str, context: dict) -> str:
        a, b = context.get("point_a"), context.get("point_b")
        entity_label = _entity_label(context.get("entity"))
        if not a or not b or a.get("amount") is None or b.get("amount") is None:
            return "비교하려는 두 시점 중 데이터가 없는 시점이 있습니다."
        unit = context.get("unit", "백만원")
        diff = context["diff"]
        pct = context.get("pct_change")
        direction = "증가" if diff > 0 else ("감소" if diff < 0 else "변동 없음")
        pct_str = f" ({pct:+.1f}%)" if pct is not None else ""
        text = (
            f"{entity_label} 기준 '{context['target']}' "
            f"{a['year']}년 {a['quarter']}분기는 {_fmt(a['amount'], unit)}, "
            f"{b['year']}년 {b['quarter']}분기는 {_fmt(b['amount'], unit)}으로, "
            f"{_fmt(abs(diff), unit)} {direction}했습니다{pct_str}."
        )
        contributors = [c for c in context.get("contributors", []) if c["diff"] != 0]
        if contributors:
            lines = [
                f"- {c['label']}: {'+' if c['diff'] > 0 else '-'}{_fmt(abs(c['diff']), c['unit'])}"
                for c in contributors
            ]
            text += "\n\n변동에 가장 크게 기여한 세부계정입니다.\n" + "\n".join(lines)
        return text

    def _handle_budget_vs_actual(self, question: str, context: dict) -> str:
        target = context.get("target")
        unit = context.get("unit", "백만원")
        year, quarter = context.get("year"), context.get("quarter")
        if not context.get("actual_found"):
            return f"{year}년 {quarter}분기 '{target}' 실적 데이터를 찾지 못했습니다."
        if not context.get("budget_found"):
            return (
                f"{year}년 {quarter}분기 '{target}' 실적은 {_fmt(context['actual'], unit)}이지만, "
                "예산(계획) 데이터가 없어 대비 결과는 보여드릴 수 없습니다. "
                "예산은 대분류(매출/매출원가 등) 단위로만 관리됩니다."
            )
        diff = context["diff"]
        rate = context["achievement_rate"]
        direction = "초과" if diff > 0 else ("미달" if diff < 0 else "동일")
        return (
            f"{year}년 {quarter}분기 '{target}' 실적은 {_fmt(context['actual'], unit)}, "
            f"예산은 {_fmt(context['budget'], unit)}으로, 예산 대비 {_fmt(abs(diff), unit)} {direction}했습니다 "
            f"(달성률 {rate:.1f}%)."
        )

    def _handle_ytd(self, question: str, context: dict) -> str:
        entity_label = _entity_label(context.get("entity"))
        target = context.get("target")
        year = context.get("year")
        if not context.get("found"):
            return f"{year}년 {entity_label} 기준 '{target}' 누적 데이터를 찾지 못했습니다."
        unit = context.get("unit", "백만원")
        quarters = context.get("quarters")
        return (
            f"{year}년 {entity_label} 기준 '{target}' 누적(YTD, {quarters}개 분기 합산)은 "
            f"{_fmt(context['amount'], unit)}입니다."
        )

    def _handle_statement(self, question: str, context: dict) -> str:
        entity_label = _entity_label(context.get("entity"))
        statement_type = context.get("statement_type")
        if not context.get("found"):
            return f"{context.get('year')}년 {context.get('quarter')}분기 {entity_label} 기준 {statement_type}를 찾지 못했습니다."

        unit = context.get("unit", "백만원")
        header = f"{context['year']}년 {context['quarter']}분기 {entity_label} 기준 {statement_type}입니다. (세부계정은 표 참고)\n"
        # "detail" 줄은 표에서만 보여주고, 요약 텍스트에는 정해진 순서의
        # 대분류 총액/계산 지표 줄만 그대로 나열한다(STATEMENT_LAYOUT 순서 유지).
        summary_lines = [f"- {line['label']}: {_fmt(line['amount'], unit)}" for line in context["lines"] if line["kind"] != "detail"]
        return header + "\n".join(summary_lines)

    def _handle_matrix(self, question: str, context: dict) -> str:
        periods = context.get("periods", [])
        entities = context.get("entities", [])
        if not periods or not entities:
            return f"'{context.get('target')}'의 매트릭스 데이터를 찾지 못했습니다."
        return (
            f"'{context['target']}' 기준으로 법인 {len(entities)}개 × 분기 {len(periods)}개 매트릭스를 만들었습니다. "
            "아래 표에서 확인하거나 CSV로 내려받으세요. 그래프에서는 규모가 큰 상위 3개 법인만 색으로 강조하고, "
            "나머지는 흐린 배경 선으로 함께 보여드립니다."
        )

    def _handle_multi_target(self, question: str, context: dict) -> str:
        series = context.get("series", [])
        entity_label = _entity_label(context.get("entity"))
        names = ", ".join(f"'{s['target']}'" for s in series)
        header = f"{entity_label} 기준 {names} 추이를 함께 보여드립니다 (그래프 참고).\n"
        lines = []
        for s in series:
            if not s["rows"]:
                lines.append(f"- {s['target']}: 데이터가 없습니다.")
                continue
            first, last = s["rows"][0], s["rows"][-1]
            lines.append(
                f"- {s['target']}: {first['year']}년 {first['quarter']}분기 {_fmt(first['amount'], s['unit'])} "
                f"→ {last['year']}년 {last['quarter']}분기 {_fmt(last['amount'], s['unit'])}"
            )
        return header + "\n".join(lines)

    def _handle_entity_target_matrix(self, question: str, context: dict) -> str:
        targets = context.get("targets", [])
        entities = context.get("entities", [])
        if not targets or not entities:
            return "지정한 계정들의 법인별 데이터를 찾지 못했습니다."
        units = context.get("units", {})
        names = ", ".join(f"'{t}'" for t in targets)
        header = f"{context['year']}년 {context['quarter']}분기 {names} 법인별 교차표입니다. (표 참고)\n"
        top_line = []
        for t in targets:
            column = context["data"].get(t, {})
            found = {e: v for e, v in column.items() if v is not None}
            if not found:
                continue
            top_entity = max(found, key=lambda e: abs(found[e]))
            top_line.append(f"- {t}: {top_entity}이 {_fmt(found[top_entity], units.get(t, '백만원'))}으로 가장 큽니다.")
        return header + "\n".join(top_line)

    def _handle_compare_entities(self, question: str, context: dict) -> str:
        rows = context.get("rows", [])
        if not rows:
            return f"지정한 법인들의 '{context.get('target')}' 데이터를 찾지 못했습니다."
        unit = context.get("unit", "백만원")
        lines = [f"- {r['entity']}: {_fmt(r['amount'], unit)}" for r in rows]
        header = f"{context['year']}년 {context['quarter']}분기 '{context['target']}' 법인 비교입니다.\n"
        footer = ""
        if len(rows) >= 2:
            top = max(rows, key=lambda r: r["amount"])
            bottom = min(rows, key=lambda r: r["amount"])
            diff = top["amount"] - bottom["amount"]
            if diff != 0:
                footer = f"\n\n{top['entity']}이 {bottom['entity']}보다 {_fmt(diff, unit)} 더 큽니다."
        return header + "\n".join(lines) + footer

    def _handle_breakdown_entity(self, question: str, context: dict) -> str:
        rows = context.get("rows", [])
        if not rows:
            return f"'{context.get('target')}'의 법인별 데이터를 찾지 못했습니다."
        unit = context.get("unit", "백만원")

        if context.get("outlier_only"):
            outliers = context.get("outliers", [])
            header = f"{context['year']}년 {context['quarter']}분기 '{context['target']}' 법인별 이상치 탐지 결과입니다 (평균 대비 표준편차 1.5배 이상 벗어난 법인, 연결조정 제외).\n"
            if not outliers:
                return header + "이상치로 보이는 법인이 없습니다. (그래프 참고)"
            lines = [
                f"- {o['entity']}: {_fmt(o['amount'], unit)} (평균 {_fmt(o['mean'], unit)}, z={o['z_score']:+.1f})"
                for o in outliers
            ]
            return header + "\n".join(lines)

        top_rows = rows[:8]
        lines = [f"- {r['entity']}: {_fmt(r['amount'], unit)}" for r in top_rows]
        more = f"\n(그 외 {len(rows) - len(top_rows)}개 법인은 그래프에서 확인하세요.)" if len(rows) > len(top_rows) else ""
        header = (
            f"{context['year']}년 {context['quarter']}분기 '{context['target']}' 법인별 현황입니다 "
            f"(기여도 큰 순, 그래프 참고).\n"
        )
        return header + "\n".join(lines) + more

    def _handle_breakdown_account(self, question: str, context: dict) -> str:
        rows = context.get("rows", [])
        entity_label = _entity_label(context.get("entity"))
        if not rows:
            return f"'{context.get('target')}'의 세부 계정 데이터를 찾지 못했습니다."
        unit = context.get("unit", "백만원")
        lines = [f"- {r['label']}: {_fmt(r['amount'], unit)}" for r in rows]
        header = (
            f"{context['year']}년 {context['quarter']}분기 {entity_label} 기준 "
            f"'{context['target']}' 세부 항목입니다 (그래프 참고).\n"
        )
        return header + "\n".join(lines)

    def _handle_account_anomaly(self, question: str, context: dict) -> str:
        rows = context.get("rows", [])
        entity_label = _entity_label(context.get("entity"))
        header = (
            f"{context['year']}년 {context['quarter']}분기 {entity_label} 기준, "
            "전분기 대비 변동이 유독 큰(이상치) 세부계정입니다.\n"
        )
        if not rows:
            return header + "이상치로 보이는 세부계정이 없습니다."
        unit = context.get("unit", "백만원")
        lines = [
            f"- {r['label']}: {_fmt(r['amount'], unit)} (전분기 {_fmt(r['prev_amount'], unit)}, "
            f"{'+' if r['diff'] > 0 else ''}{_fmt(r['diff'], unit)}, z={r['z_score']:+.1f})"
            for r in rows
        ]
        return header + "\n".join(lines)

    def _handle_new_accounts(self, question: str, context: dict) -> str:
        rows = context.get("rows", [])
        entity_label = _entity_label(context.get("entity"))
        header = (
            f"{context['year']}년 {context['quarter']}분기 {entity_label} 기준, "
            "직전 분기에는 없었는데 이번 분기에 새로 실적이 생긴 세부계정입니다.\n"
        )
        if not rows:
            return header + "새로 생긴 세부계정이 없습니다."
        unit = context.get("unit", "백만원")
        lines = [f"- {r['label']}: {_fmt(r['amount'], unit)}" for r in rows]
        return header + "\n".join(lines)

    def _handle_list_accounts(self, question: str, context: dict) -> str:
        accounts = context.get("accounts", {})
        level1 = accounts.get("level1", [])
        if not level1:
            return "적재된 결산 데이터가 없습니다. 먼저 data/raw에 파일을 넣고 적재를 실행해 주세요."
        metrics = accounts.get("metrics", [])
        ratios = accounts.get("ratios", [])
        return (
            "조회 가능한 대분류 계정입니다.\n" + ", ".join(level1) +
            "\n\n자주 쓰는 계산 지표: " + ", ".join(metrics) +
            "\n비율 지표: " + ", ".join(ratios) +
            "\n\n중분류/세부계정은 대분류보다 더 구체적인 이름으로 바로 물어보셔도 됩니다. "
            "(예: '광고선전비 얼마야', '매출채권 추이 보여줘')"
        )

    def _handle_unresolved(self, question: str, context: dict) -> str:
        reason = context.get("reason")
        if reason == "no_period":
            return "기간(연도/분기)을 찾지 못했습니다. '2024년 3분기'처럼 알려주시거나 '이번분기', '작년' 같은 표현을 써주세요."
        examples = context.get(
            "examples",
            [
                "3분기 영업이익 알려줘",
                "매출 추이 보여줘",
                "작년 4분기랑 이번분기 순이익 비교해줘",
                "영업이익 법인별로 보여줘",
                "계정 목록 보여줘",
            ],
        )
        example_lines = "\n".join(f"- {e}" for e in examples)
        return (
            "질문을 이해하지 못했습니다. 계정명(또는 매출/영업이익 등 지표명)을 포함해서 "
            "아래처럼 물어봐 주세요.\n" + example_lines
        )
