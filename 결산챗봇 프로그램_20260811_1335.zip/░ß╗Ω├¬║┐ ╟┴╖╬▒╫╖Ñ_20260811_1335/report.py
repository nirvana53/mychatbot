"""분기 마감 요약 리포트 생성기 (Markdown / Excel).

주요 지표(QoQ/YoY/예산 대비)와 이상치·신규계정을 한 번에 모아, 담당자가
분기 마감 때마다 매번 여러 질문을 반복하지 않고 문서 하나로 받아볼 수
있게 한다. query_engine.query만 사용하며(LLM 호출 없음, 자연어 설명이
아니라 표/목록 형태), 조회 로직은 챗봇 답변에 쓰는 것과 동일한 함수를
그대로 재사용한다. Markdown 버전은 채팅 안에서 바로 읽기 좋고, Excel
버전(.xlsx)은 경영진 배포·인쇄용으로 서식(굵은 헤더/합계)을 갖춘 문서가
필요할 때 쓴다 — 둘 다 같은 REPORT_KPIS/조회 결과를 재사용해서 두 출력이
서로 어긋나지 않게 한다.
"""

from datetime import datetime
from io import BytesIO

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font

from query_engine import query

REPORT_KPIS = [
    ("매출", "level1"),
    ("매출총이익", "metric"),
    ("영업이익", "metric"),
    ("당기순이익", "metric"),
    ("영업이익률", "ratio"),
]


def _fmt_amount(amount: float, unit: str) -> str:
    return f"{amount:.1f}%" if unit == "%" else f"{amount:,.0f}{unit}"


def _fmt_change(change: dict, unit: str) -> str:
    if not change or change.get("diff") is None:
        return "-"
    if unit == "%":
        return f"{change['diff']:+.1f}%p"
    pct = change.get("pct_change")
    pct_str = f" ({pct:+.1f}%)" if pct is not None else ""
    return f"{change['diff']:+,.0f}{unit}{pct_str}"


def build_quarterly_report(year: int, quarter: int) -> str:
    lines = [
        f"# {year}년 {quarter}분기 결산 요약 리포트",
        "",
        f"생성 시각: {datetime.now().isoformat(timespec='seconds')} (연결 기준)",
        "",
        "## 주요 지표",
        "",
        "| 지표 | 실적 | 전분기 대비 | 전년동기 대비 | 예산 대비 |",
        "|---|---|---|---|---|",
    ]

    for name, level in REPORT_KPIS:
        result = query.get_amount(year, quarter, name, level)
        if not result.get("found"):
            lines.append(f"| {name} | - | - | - | - |")
            continue
        unit = result.get("unit", "백만원")
        changes = query.get_period_comparisons(year, quarter, name, level)
        bva = query.get_budget_vs_actual(year, quarter, name, level)
        bva_str = f"달성률 {bva['achievement_rate']:.1f}%" if bva.get("actual_found") and bva.get("budget_found") else "-"
        lines.append(
            f"| {name} | {_fmt_amount(result['amount'], unit)} | "
            f"{_fmt_change(changes.get('qoq'), unit)} | {_fmt_change(changes.get('yoy'), unit)} | {bva_str} |"
        )

    lines += ["", "## 세부계정 이상치 (전분기 대비 변동이 유독 큰 계정)", ""]
    anomalies = query.detect_account_anomalies(year, quarter)
    if not anomalies:
        lines.append("- 없음")
    else:
        for a in anomalies:
            lines.append(
                f"- {a['label']}: {_fmt_amount(a['amount'], a['unit'])} "
                f"(전분기 {_fmt_amount(a['prev_amount'], a['unit'])}, {a['diff']:+,.0f}{a['unit']}, z={a['z_score']:+.1f})"
            )

    lines += ["", "## 신규 발생 계정 (직전 분기에는 없던 세부계정)", ""]
    new_accounts = query.get_new_accounts(year, quarter)
    if not new_accounts:
        lines.append("- 없음")
    else:
        for n in new_accounts:
            lines.append(f"- {n['label']}: {_fmt_amount(n['amount'], n['unit'])}")

    lines += ["", "## 법인별 이상치 (매출 기준)", ""]
    entity_outliers = query.detect_entity_outliers(year, quarter, "매출", "level1")
    if not entity_outliers:
        lines.append("- 없음")
    else:
        for o in entity_outliers:
            lines.append(
                f"- {o['entity']}: {_fmt_amount(o['amount'], o['unit'])} "
                f"(평균 {_fmt_amount(o['mean'], o['unit'])}, z={o['z_score']:+.1f})"
            )

    return "\n".join(lines) + "\n"


_HEADER_FONT = Font(bold=True)
_TITLE_FONT = Font(bold=True, size=14)


def _autosize_columns(ws, min_width: int = 10, max_width: int = 40) -> None:
    for col_cells in ws.columns:
        length = max((len(str(c.value)) for c in col_cells if c.value is not None), default=0)
        ws.column_dimensions[col_cells[0].column_letter].width = max(min_width, min(length + 2, max_width))


def build_quarterly_report_xlsx(year: int, quarter: int) -> bytes:
    """분기 마감 요약 리포트의 엑셀(.xlsx) 버전. 시트 4개(요약/세부계정 이상치/
    신규 발생 계정/법인별 이상치)로 나누고, 헤더와 지표명만 굵게 처리한다.
    """
    wb = Workbook()

    ws = wb.active
    ws.title = "요약"
    ws["A1"] = f"{year}년 {quarter}분기 결산 요약 리포트"
    ws["A1"].font = _TITLE_FONT
    ws["A2"] = f"생성 시각: {datetime.now().isoformat(timespec='seconds')} (연결 기준)"

    headers = ["지표", "실적", "전분기 대비", "전년동기 대비", "예산 대비"]
    ws.append([])
    ws.append(headers)
    for cell in ws[ws.max_row]:
        cell.font = _HEADER_FONT

    for name, level in REPORT_KPIS:
        result = query.get_amount(year, quarter, name, level)
        if not result.get("found"):
            ws.append([name, "-", "-", "-", "-"])
            continue
        unit = result.get("unit", "백만원")
        changes = query.get_period_comparisons(year, quarter, name, level)
        bva = query.get_budget_vs_actual(year, quarter, name, level)
        bva_str = f"달성률 {bva['achievement_rate']:.1f}%" if bva.get("actual_found") and bva.get("budget_found") else "-"
        ws.append([
            name, _fmt_amount(result["amount"], unit),
            _fmt_change(changes.get("qoq"), unit), _fmt_change(changes.get("yoy"), unit), bva_str,
        ])
        ws.cell(row=ws.max_row, column=1).font = _HEADER_FONT
    _autosize_columns(ws)

    ws2 = wb.create_sheet("세부계정 이상치")
    ws2.append(["세부계정", "실적", "전분기", "변동", "z-score"])
    for cell in ws2[1]:
        cell.font = _HEADER_FONT
    for a in query.detect_account_anomalies(year, quarter):
        ws2.append([a["label"], _fmt_amount(a["amount"], a["unit"]), _fmt_amount(a["prev_amount"], a["unit"]),
                    f"{a['diff']:+,.0f}{a['unit']}", f"{a['z_score']:+.1f}"])
    _autosize_columns(ws2)

    ws3 = wb.create_sheet("신규 발생 계정")
    ws3.append(["세부계정", "실적"])
    for cell in ws3[1]:
        cell.font = _HEADER_FONT
    for n in query.get_new_accounts(year, quarter):
        ws3.append([n["label"], _fmt_amount(n["amount"], n["unit"])])
    _autosize_columns(ws3)

    ws4 = wb.create_sheet("법인별 이상치")
    ws4.append(["법인", "실적", "평균", "z-score"])
    for cell in ws4[1]:
        cell.font = _HEADER_FONT
    for o in query.detect_entity_outliers(year, quarter, "매출", "level1"):
        ws4.append([o["entity"], _fmt_amount(o["amount"], o["unit"]), _fmt_amount(o["mean"], o["unit"]), f"{o['z_score']:+.1f}"])
    _autosize_columns(ws4)

    for sheet in wb.worksheets:
        sheet.freeze_panes = "A2"

    buffer = BytesIO()
    wb.save(buffer)
    return buffer.getvalue()
