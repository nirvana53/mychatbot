"""SQLite(finance.db)에서 연결결산 데이터를 조회/집계하는 함수 모음.

데이터는 (법인 20개 + 연결조정)의 3단계 계정트리(대분류-중분류-세부계정)로
저장되어 있다. entity를 지정하지 않으면 모든 법인 + 연결조정을 합산한
"연결" 기준 값을 돌려준다(법인별 데이터 + 연결조정 = 연결결산이라는
전제와 그대로 맞는 동작이다). 특정 법인명을 넘기면 그 법인만 걸러서
조회한다(드릴다운).

챗봇 오케스트레이터(chatbot.py)가 nlu.parse_question()의 결과에 따라
이 모듈의 함수를 호출해서 실제 숫자를 가져온다. 숫자 계산은 항상 이
모듈(=DB 조회)에서만 하고, LLM에게는 결과를 문장으로 다듬는 역할만
맡기는 것이 원칙이다.
"""

import sqlite3

import config

# 여러 대분류를 더하고 빼서 만드는 계산 지표. 원본 데이터에는 이 항목들이
# 행으로 저장되어 있지 않고, 조회 시점에 대분류 합계로 계산한다.
COMPUTED_METRICS = {
    "매출총이익": [("매출", 1), ("매출원가", -1)],
    "영업이익": [("매출", 1), ("매출원가", -1), ("판매비와관리비", -1)],
    "당기순이익": [
        ("매출", 1), ("매출원가", -1), ("판매비와관리비", -1),
        ("영업외수익", 1), ("영업외비용", -1), ("법인세", -1),
    ],
}

# 두 계산 지표(또는 대분류)의 비율로 만드는 지표. (분자, 분모) 각각
# COMPUTED_METRICS에 있으면 metric으로, 아니면 level1 대분류 합계로 계산한다.
RATIO_METRICS = {
    "영업이익률": ("영업이익", "매출"),
    "매출원가율": ("매출원가", "매출"),
    "부채비율": ("부채", "자본"),
    "ROE": ("당기순이익", "자본"),
    "ROA": ("당기순이익", "자산"),
}

UNIT = "백만원"
RATIO_UNIT = "%"


def _connect():
    return sqlite3.connect(config.DB_PATH)


def list_entities() -> list:
    try:
        with _connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT entity FROM financial_statements ORDER BY entity"
            ).fetchall()
        return [r[0] for r in rows]
    except sqlite3.OperationalError:
        return []


def list_accounts() -> dict:
    """레벨별 계정명과 계산 지표 이름을 함께 반환한다."""
    try:
        with _connect() as conn:
            level1 = [r[0] for r in conn.execute(
                "SELECT DISTINCT level1 FROM financial_statements ORDER BY level1"
            ).fetchall()]
            level2 = [r[0] for r in conn.execute(
                "SELECT DISTINCT level2 FROM financial_statements WHERE level2 IS NOT NULL ORDER BY level2"
            ).fetchall()]
            level3 = [r[0] for r in conn.execute(
                "SELECT DISTINCT level3 FROM financial_statements WHERE level3 IS NOT NULL ORDER BY level3"
            ).fetchall()]
        return {
            "level1": level1,
            "level2": level2,
            "level3": level3,
            "metrics": list(COMPUTED_METRICS.keys()),
            "ratios": list(RATIO_METRICS.keys()),
        }
    except sqlite3.OperationalError:
        return {"level1": [], "level2": [], "level3": [], "metrics": [], "ratios": []}


def get_periods() -> list:
    try:
        with _connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT year, quarter FROM financial_statements ORDER BY year, quarter"
            ).fetchall()
        return [(r[0], r[1]) for r in rows]
    except sqlite3.OperationalError:
        return []


def _level_column(level: str) -> str:
    return {"level1": "level1", "level2": "level2", "level3": "level3"}[level]


def _sum_leaf(conn, year, quarter, level, value, entity=None):
    column = _level_column(level)
    query = f"SELECT COALESCE(SUM(amount),0) FROM financial_statements WHERE year=? AND quarter=? AND {column}=?"
    params = [year, quarter, value]
    if entity:
        query += " AND entity=?"
        params.append(entity)
    return conn.execute(query, params).fetchone()[0]


def _has_data(conn, year, quarter, level, value, entity=None):
    column = _level_column(level)
    query = f"SELECT 1 FROM financial_statements WHERE year=? AND quarter=? AND {column}=?"
    params = [year, quarter, value]
    if entity:
        query += " AND entity=?"
        params.append(entity)
    query += " LIMIT 1"
    return conn.execute(query, params).fetchone() is not None


def get_amount(year: int, quarter: int, target: str, level: str, entity: str | None = None) -> dict:
    """entity가 None이면 법인 20개 + 연결조정을 모두 합산한 연결 기준 값."""
    if level == "ratio":
        spec = RATIO_METRICS.get(target)
        if spec is None:
            return {"found": False}
        num_name, den_name = spec
        num = get_amount(year, quarter, num_name, "metric" if num_name in COMPUTED_METRICS else "level1", entity)
        den = get_amount(year, quarter, den_name, "metric" if den_name in COMPUTED_METRICS else "level1", entity)
        if not (num.get("found") and den.get("found")) or not den.get("amount"):
            return {"found": False}
        return {"found": True, "amount": num["amount"] / den["amount"] * 100, "unit": RATIO_UNIT}

    with _connect() as conn:
        if level == "metric":
            formula = COMPUTED_METRICS.get(target)
            if formula is None:
                return {"found": False}
            total = 0.0
            any_found = False
            for level1_value, sign in formula:
                if _has_data(conn, year, quarter, "level1", level1_value, entity):
                    any_found = True
                total += sign * _sum_leaf(conn, year, quarter, "level1", level1_value, entity)
            if not any_found:
                return {"found": False}
            return {"found": True, "amount": total, "unit": UNIT}

        if not _has_data(conn, year, quarter, level, target, entity):
            return {"found": False}
        amount = _sum_leaf(conn, year, quarter, level, target, entity)
    return {"found": True, "amount": amount, "unit": UNIT}


def get_trend(target: str, level: str, entity: str | None = None, year: int | None = None,
              period_start: tuple | None = None, period_end: tuple | None = None) -> list:
    periods = get_periods()
    if period_start is not None and period_end is not None:
        periods = [p for p in periods if period_start <= p <= period_end]
    elif year is not None:
        periods = [p for p in periods if p[0] == year]
    rows = []
    for y, q in periods:
        result = get_amount(y, q, target, level, entity)
        if result.get("found"):
            rows.append({"year": y, "quarter": q, "amount": result["amount"], "unit": result.get("unit", UNIT)})
    return rows


def compare_periods(target: str, level: str, period_a: tuple, period_b: tuple, entity: str | None = None) -> dict:
    a = get_amount(period_a[0], period_a[1], target, level, entity)
    b = get_amount(period_b[0], period_b[1], target, level, entity)
    result = {
        "point_a": {"year": period_a[0], "quarter": period_a[1], "amount": a.get("amount")},
        "point_b": {"year": period_b[0], "quarter": period_b[1], "amount": b.get("amount")},
        "unit": a.get("unit") or b.get("unit") or UNIT,
    }
    if a.get("found") and b.get("found"):
        diff = b["amount"] - a["amount"]
        result["diff"] = diff
        result["pct_change"] = (diff / a["amount"] * 100) if a["amount"] else None
    return result


def get_period_comparisons(year: int, quarter: int, target: str, level: str, entity: str | None = None) -> dict:
    """단일 시점 조회에 자동으로 곁들이는 전분기(QoQ)/전년동기(YoY) 비교."""
    periods = get_periods()
    result = {}
    if (year, quarter) in periods:
        idx = periods.index((year, quarter))
        if idx > 0:
            prev = periods[idx - 1]
            result["qoq"] = compare_periods(target, level, prev, (year, quarter), entity)
    yoy_period = (year - 1, quarter)
    if yoy_period in periods:
        result["yoy"] = compare_periods(target, level, yoy_period, (year, quarter), entity)
    return result


def compare_subaccount_contributions(target: str, level: str, period_a: tuple, period_b: tuple,
                                      entity: str | None = None, top_n: int = 5) -> list:
    """두 시점 사이의 변동을 세부계정 단위로 쪼개서, 변동에 가장 크게 기여한 항목부터 보여준다."""
    a_rows = breakdown_by_subaccount(period_a[0], period_a[1], level, target, entity)
    b_rows = breakdown_by_subaccount(period_b[0], period_b[1], level, target, entity)
    a_map = {r["label"]: r["amount"] for r in a_rows}
    b_map = {r["label"]: r["amount"] for r in b_rows}
    diffs = [
        {"label": label, "diff": b_map.get(label, 0) - a_map.get(label, 0), "unit": UNIT}
        for label in (set(a_map) | set(b_map))
    ]
    diffs.sort(key=lambda d: -abs(d["diff"]))
    return diffs[:top_n]


def breakdown_by_entity(year: int, quarter: int, target: str, level: str) -> list:
    """법인별(+연결조정) 기여도 breakdown. 절대값이 큰 순서로 정렬."""
    entities = list_entities()
    rows = []
    for e in entities:
        result = get_amount(year, quarter, target, level, entity=e)
        if result.get("found"):
            rows.append({"entity": e, "amount": result["amount"], "unit": result.get("unit", UNIT)})
    rows.sort(key=lambda r: -abs(r["amount"]))
    return rows


def _level3_amounts(year: int, quarter: int, entity: str | None = None) -> dict:
    query = """SELECT level3, COALESCE(SUM(amount),0) FROM financial_statements
               WHERE year=? AND quarter=? AND level3 IS NOT NULL"""
    params = [year, quarter]
    if entity:
        query += " AND entity=?"
        params.append(entity)
    query += " GROUP BY level3"
    with _connect() as conn:
        rows = conn.execute(query, params).fetchall()
    return {r[0]: r[1] for r in rows}


def get_new_accounts(year: int, quarter: int, entity: str | None = None) -> list:
    """직전 분기에는 금액이 없었는데(0 또는 미기록) 이번 분기에 처음 생긴 세부계정."""
    periods = get_periods()
    if (year, quarter) not in periods or periods.index((year, quarter)) == 0:
        return []
    prev_year, prev_quarter = periods[periods.index((year, quarter)) - 1]

    current = _level3_amounts(year, quarter, entity)
    previous = _level3_amounts(prev_year, prev_quarter, entity)
    new_items = [
        {"label": label, "amount": amount, "unit": UNIT}
        for label, amount in current.items()
        if amount != 0 and previous.get(label, 0) == 0
    ]
    new_items.sort(key=lambda r: -abs(r["amount"]))
    return new_items


def detect_account_anomalies(year: int, quarter: int, entity: str | None = None, z_threshold: float = 1.5) -> list:
    """법인 단위가 아니라 세부계정 단위로, 전분기 대비 변동이 유독 큰 계정을 찾는다."""
    periods = get_periods()
    if (year, quarter) not in periods or periods.index((year, quarter)) == 0:
        return []
    prev_year, prev_quarter = periods[periods.index((year, quarter)) - 1]

    current = _level3_amounts(year, quarter, entity)
    previous = _level3_amounts(prev_year, prev_quarter, entity)
    diffs = [
        {"label": label, "amount": amount, "prev_amount": previous.get(label, 0),
         "diff": amount - previous.get(label, 0), "unit": UNIT}
        for label, amount in current.items()
    ]
    if len(diffs) < 3:
        return []
    diff_values = [d["diff"] for d in diffs]
    mean = sum(diff_values) / len(diff_values)
    std = (sum((v - mean) ** 2 for v in diff_values) / len(diff_values)) ** 0.5
    if std == 0:
        return []
    outliers = [{**d, "z_score": (d["diff"] - mean) / std} for d in diffs if abs((d["diff"] - mean) / std) >= z_threshold]
    outliers.sort(key=lambda r: -abs(r["z_score"]))
    return outliers


def get_amounts_for_entities(year: int, quarter: int, target: str, level: str, entities: list) -> list:
    """사용자가 직접 지정한 법인들만 나란히 비교할 때 쓴다."""
    rows = []
    for e in entities:
        result = get_amount(year, quarter, target, level, entity=e)
        if result.get("found"):
            rows.append({"entity": e, "amount": result["amount"], "unit": result.get("unit", UNIT)})
    return rows


def detect_entity_outliers(year: int, quarter: int, target: str, level: str, z_threshold: float = 1.5) -> list:
    """법인별 금액 분포에서 평균과 표준편차 대비 크게 벗어난 법인을 찾는다.

    연결조정은 법인들의 실적을 맞추기 위한 잔차(plug)라 다른 법인과 성격이
    달라서, 평균/표준편차 계산과 이상치 판정 모두에서 제외한다.
    """
    rows = [r for r in breakdown_by_entity(year, quarter, target, level) if r["entity"] != "연결조정"]
    if len(rows) < 3:
        return []
    amounts = [r["amount"] for r in rows]
    mean = sum(amounts) / len(amounts)
    std = (sum((a - mean) ** 2 for a in amounts) / len(amounts)) ** 0.5
    if std == 0:
        return []
    outliers = []
    for r in rows:
        z = (r["amount"] - mean) / std
        if abs(z) >= z_threshold:
            outliers.append({**r, "z_score": z, "mean": mean})
    outliers.sort(key=lambda r: -abs(r["z_score"]))
    return outliers


def breakdown_by_subaccount(year: int, quarter: int, level: str, value: str, entity: str | None = None) -> list:
    """계정트리를 한 단계 더 파고든다: 대분류 -> 중분류, 중분류 -> 세부계정."""
    if level == "level1":
        group_col, filter_col = "level2", "level1"
    elif level == "level2":
        group_col, filter_col = "level3", "level2"
    else:
        return []

    query = f"""SELECT {group_col}, COALESCE(SUM(amount),0) FROM financial_statements
                WHERE year=? AND quarter=? AND {filter_col}=? AND {group_col} IS NOT NULL"""
    params = [year, quarter, value]
    if entity:
        query += " AND entity=?"
        params.append(entity)
    query += f" GROUP BY {group_col} ORDER BY {group_col}"

    with _connect() as conn:
        rows = conn.execute(query, params).fetchall()
    return [{"label": r[0], "amount": r[1], "unit": UNIT} for r in rows]
